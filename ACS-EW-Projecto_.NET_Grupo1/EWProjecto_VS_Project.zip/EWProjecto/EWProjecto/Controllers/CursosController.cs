﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class CursosController : Controller
    {
        //
        // GET: /Cursos/

        [Authorize(Roles = "Administrador")]
        public ActionResult Index(int? page)
        {
            List<DescricaoCurso> listaCursos = DescricoesCurso.getAllCursos();
            listaCursos = listaCursos.OrderBy(lc => lc.descricao).ToList();
            CursoModel model = new CursoModel(listaCursos, page ?? 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Editar(string sigla)
        {
            List<CursoAno> anosCurso = CursosAnos.getCursoAno(sigla);
            ViewBag.anosCurso = anosCurso.OrderBy(ac => ac.ano);
            ViewBag.sigla = sigla;
            ViewBag.username = User.Identity.Name;

            return View();
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Add()
        {
            CursoModel model = new CursoModel();
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(CursoModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = DescricoesCurso.insere(model.sigla, model.descricao);
                if (inserted)
                {
                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Add", "AnosCurso", new { sigla = model.sigla });
                }
                else
                {
                    ModelState.AddModelError("", "Curso já existente");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(string sigla)
        {
            DescricoesCurso.remove(sigla);
            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Index", "Cursos");
        }
    }
}
