﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;


namespace EWProjecto.Controllers
{
    public class PesquisaController : Controller
    {
        //
        // GET: /Pesquisa/

        public ActionResult Curso(int? page, string curso)
        {
            PesquisaModel model;
            if (curso != null)
            {
                List<ListaMaterialDidactico> listasMaterial = ListasMaterialDidactico.getListasMaterialDidacticoSigla(curso);
                model = new PesquisaModel(listasMaterial, page ?? 0);
                model.curso = curso;
            }
            else
            {
                model = new PesquisaModel();
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost]
        public ActionResult Curso(PesquisaModel model)
        {
            List<ListaMaterialDidactico> listasMaterial = ListasMaterialDidactico.getListasMaterialDidacticoSigla(model.curso);
            model.setListasAndPage(listasMaterial, 0);

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        public ActionResult Disciplina(int? page, int? disciplina)
        {
            PesquisaModel model;
            if (disciplina.HasValue == true)
            {
                List<MaterialDidactico> listaMateriais = MateriaisDidacticos.getMaterialDidaticoDisciplina(disciplina.Value);
                model = new PesquisaModel(listaMateriais, page ?? 0);
                model.oidDisciplina = disciplina.Value;
                model.nomeDisciplina = Disciplinas.getDisciplina(disciplina.Value).nome;
            }
            else
            {
                model = new PesquisaModel();
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost]
        public ActionResult Disciplina(PesquisaModel model)
        {
            List<MaterialDidactico> listaMateriais = MateriaisDidacticos.getMaterialDidaticoDisciplina(model.oidDisciplina);
            model.setMateriaisAndPage(listaMateriais, 0);

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Estudante")]
        public ActionResult Imprimir(PesquisaModel model)
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            PedidosImpressao.insere(model.pedidoCor, model.pedidoFrenteVerso, model.pedidoNrCopias, model.pedidoPaginasFolha, estudante.oidUtilizador, model.oid);

            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Disciplina", "Pesquisa", new { disciplina = model.oidDisciplina });
        }

    }
}
