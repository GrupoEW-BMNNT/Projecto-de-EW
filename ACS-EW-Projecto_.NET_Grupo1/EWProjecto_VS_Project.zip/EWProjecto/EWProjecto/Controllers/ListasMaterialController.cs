﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class ListasMaterialController : Controller
    {
        //
        // GET: /ListasMaterial/

        public ActionResult Index(int? page, string anoLectivo)
        {
            List<AnoLectivo> anosLectivos = AnosLectivos.getAllAnoLectivo().OrderByDescending(al => al.Ano).ToList();
            string anoLectivoAtual = "";
            if (anosLectivos != null)
            {
                anoLectivoAtual = anoLectivo != null ? anoLectivo : anosLectivos.FirstOrDefault().Ano;
            }
            List<ListaMaterialDidactico> listas = ListasMaterialDidactico.getListasMaterialDidacticoAnoLectivo(anoLectivoAtual);
            ListasMaterialModel model = new ListasMaterialModel(listas, page ?? 0);
            model.anoLectivo = anoLectivo != null ? anoLectivo : "";
            model.anosLectivos = new SelectList(AnosLectivos.getAllAnoLectivo(), "Ano", "Ano");

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost]
        public ActionResult Index(ListasMaterialModel m)
        {
            List<ListaMaterialDidactico> listas = ListasMaterialDidactico.getListasMaterialDidacticoAnoLectivo(m.anoLectivo);
            m.setListasAndPage(listas, 0);
            m.anosLectivos = new SelectList(AnosLectivos.getAllAnoLectivo(), "Ano", "Ano");

            ViewBag.username = User.Identity.Name;

            return View(m);
        }

        public ActionResult Editar(int oid, int? page)
        {
            List<MaterialDidactico> materiais = MateriaisDidacticos.getMaterialDidaticoListaMaterial(oid);
            materiais = materiais.OrderBy(m => m.nome).ToList();
            ListaMaterialDidactico lmd = ListasMaterialDidactico.getListaMaterialDidactico(oid);
            ViewBag.lmd = lmd;

            MaterialModel model = new MaterialModel(materiais, page ?? 0);
            model.oidLista = oid;

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Estudante")]
        public ActionResult Editar(MaterialModel model)
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            PedidosImpressao.insere(model.pedidoCor, model.pedidoFrenteVerso, model.pedidoNrCopias, model.pedidoPaginasFolha, estudante.oidUtilizador, model.oid);
            List<MaterialDidactico> materiais = MateriaisDidacticos.getMaterialDidaticoListaMaterial(model.oidLista);
            materiais = materiais.OrderBy(m => m.nome).ToList();
            ListaMaterialDidactico lmd = ListasMaterialDidactico.getListaMaterialDidactico(model.oidLista);
            ViewBag.lmd = lmd;
            model.setMateriaisAndPage(materiais, 0);

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Add()
        {
            ListasMaterialModel model = new ListasMaterialModel();
            model.anosLectivos = new SelectList(AnosLectivos.getAllAnoLectivo(), "Ano", "Ano");

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(ListasMaterialModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = ListasMaterialDidactico.insere(model.descricao, model.anoLectivo, model.oidCurso);
                if (inserted)
                {
                    ListaMaterialDidactico lmd = ListasMaterialDidactico.getListaMaterialDidactico(model.anoLectivo, model.oidCurso);
                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Add", "Material", new { oid = lmd.oid });
                }
                else
                {
                    ModelState.AddModelError("", "Lista de material já existente");
                }
            }

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(int oid)
        {
            ListasMaterialDidactico.remove(oid);

            ViewBag.username = User.Identity.Name;

            return RedirectToAction("Index", "ListasMaterial");
        }

    }
}
