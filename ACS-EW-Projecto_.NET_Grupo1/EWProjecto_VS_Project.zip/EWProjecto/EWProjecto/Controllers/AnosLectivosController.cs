﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class AnosLectivosController : Controller
    {
        //
        // GET: /AnosLectivos/

        [Authorize(Roles = "Administrador")]
        public ActionResult Index(int? page)
        {
            List<AnoLectivo> anosLectivos = AnosLectivos.getAllAnoLectivo();
            anosLectivos = anosLectivos.OrderByDescending(al => al.Ano).ToList();
            AnoLectivoModel model = new AnoLectivoModel(anosLectivos, page ?? 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Index(AnoLectivoModel m)
        {
            List<AnoLectivo> anosLectivos = AnosLectivos.getAllAnoLectivo();
            anosLectivos = anosLectivos.OrderByDescending(al => al.Ano).ToList();
            AnoLectivoModel model = new AnoLectivoModel(anosLectivos, 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Add()
        {
            AnoLectivoModel model = new AnoLectivoModel();
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(AnoLectivoModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = AnosLectivos.insere(model.anoLectivo);
                if (inserted)
                {
                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Index", "AnosLectivos");
                }
                else
                {
                    ModelState.AddModelError("", "Ano lectivo já existente");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(string ano)
        {
            AnosLectivos.remove(ano);
            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Index", "AnosLectivos");
        }

    }
}
