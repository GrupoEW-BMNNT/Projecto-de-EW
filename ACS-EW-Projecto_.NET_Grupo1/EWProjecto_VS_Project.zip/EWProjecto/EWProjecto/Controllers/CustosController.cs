﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class CustosController : Controller
    {
        //
        // GET: /Custos/

        [Authorize(Roles = "Administrador")]
        public ActionResult Index()
        {
            List<Custo> custos = Costs.getAllCustos();
            ViewBag.custos = custos.OrderBy(c => c.descricao);
            ViewBag.username = User.Identity.Name;

            return View();
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Add()
        {
            CustoModel model = new CustoModel();
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(CustoModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = Costs.insere(model.descricao, model.custo);
                if (inserted)
                {
                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Index", "Custos");
                }
                else
                {
                    ModelState.AddModelError("", "Custo já existente");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(int oid)
        {
            Costs.remove(oid);
            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Index", "Custos");
        }
    }
}
