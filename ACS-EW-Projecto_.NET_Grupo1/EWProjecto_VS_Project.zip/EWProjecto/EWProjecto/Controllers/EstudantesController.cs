﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;
using System.Web.Security;

namespace EWProjecto.Controllers
{
    public class EstudantesController : Controller
    {
        //
        // GET: /Estudantes/

        [Authorize(Roles = "Administrador")]
        public ActionResult Index(int? page)
        {
            List<Estudante> estudantes = Estudantes.getAllEstudantes();
            estudantes = estudantes.OrderBy(e => e.Utilizador.username).ToList();
            EstudanteModel model = new EstudanteModel(estudantes, page ?? 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Add()
        {
            EstudanteModel model = new EstudanteModel();
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(EstudanteModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = Estudantes.insere(model.contacto, model.email, model.oidCurso, model.password, model.username);
                if (inserted)
                {
                    if (!Roles.IsUserInRole(model.username, "Estudante"))
                    {
                        Roles.AddUserToRole(model.username, "Estudante");
                    }

                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Index", "Estudantes");
                }
                else
                {
                    ModelState.AddModelError("", "Estudante já existente");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(string username)
        {
            Estudantes.remove(username);
            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Index", "Estudantes");
        }

    }
}
