﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EWProjecto.Controllers
{
    public class PopulateController : Controller
    {
        //
        // GET: /Populate/

        public ActionResult Index()
        {
            ViewBag.username = User.Identity.Name;
            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection formValues)
        {
            EWProjecto.Models.Testing.Populate.Popular();
            ViewBag.username = User.Identity.Name;
            return View();
        }

    }
}
