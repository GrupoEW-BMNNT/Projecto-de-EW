﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models.ModelViews;
using EWProjecto.Models;

namespace EWProjecto.Controllers
{
    public class PerfilController : Controller
    {
        //
        // GET: /Perfil/

        [Authorize(Roles = "Estudante")]
        public ActionResult Index()
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            ViewBag.estudante = estudante;

            ViewBag.username = User.Identity.Name;

            return View();
        }

        [Authorize(Roles = "Estudante")]
        public ActionResult Editar()
        {
            PerfilModel model = new PerfilModel();
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            List<CursoAno> cursos = CursosAnos.getCursoAno(estudante.CursoAno.oidSigla);

            model.anosCurso = new SelectList(cursos, "oid", "ano");
            model.contacto = estudante.contacto;
            model.curso = estudante.CursoAno.oidSigla;
            model.email = estudante.email;
            model.oidCurso = estudante.oidCursoAno;
            model.password = estudante.Utilizador.password;
            model.username = estudante.Utilizador.username;

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Estudante")]
        public ActionResult Editar(PerfilModel model)
        {
            if (ModelState.IsValid)
            {
                Estudantes.actualiza(model.contacto, model.email, model.oidCurso, model.password, model.username);
                ViewBag.username = User.Identity.Name;

                return RedirectToAction("AlterarPerfil", "Perfil");
            }

            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            List<CursoAno> cursos = CursosAnos.getCursoAno(estudante.CursoAno.oidSigla);
            model.anosCurso = new SelectList(cursos, "oid", "ano");

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Estudante")]
        public ActionResult AlterarPerfil()
        {
            ViewBag.Mensagem = "Perfil alterado com sucesso";
            ViewBag.username = User.Identity.Name;

            return View();
        }

    }
}
