﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;
using System.Web.Security;

namespace EWProjecto.Controllers
{
    public class AdministradoresController : Controller
    {
        //
        // GET: /Administradores/

        [Authorize(Roles = "Administrador")]
        public ActionResult Index(int? page)
        {
            List<Utilizador> administradores = Utilizadores.getAllOnlyUtilizadores();
            administradores = administradores.OrderBy(a => a.username).ToList();
            AdministradorModel model = new AdministradorModel(administradores, page ?? 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Index(AdministradorModel m)
        {
            List<Utilizador> administradores = Utilizadores.getAllOnlyUtilizadores();
            administradores = administradores.OrderBy(a => a.username).ToList();
            AdministradorModel model = new AdministradorModel(administradores, 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Add()
        {
            AdministradorModel model = new AdministradorModel(new List<Utilizador>(), 0);
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(AdministradorModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = Utilizadores.insere(model.username, model.password);

                if (inserted)
                {
                    if (!Roles.IsUserInRole(model.username, "Administrador"))
                    {
                        Roles.AddUserToRole(model.username, "Administrador");
                    }

                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Index", "Administradores");
                }
                else
                {
                    ModelState.AddModelError("", "Administrador já existente");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(string username)
        {
            Utilizadores.remove(username);
            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Index", "Administradores");
        }
    }
}
