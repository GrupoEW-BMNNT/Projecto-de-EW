﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models.ModelViews;
using EWProjecto.Models;

namespace EWProjecto.Controllers
{
    public class MaterialController : Controller
    {
        //
        // GET: /Material/

        public ActionResult Index(int oid)
        {
            MaterialModel model = new MaterialModel();
            MaterialDidactico md = MateriaisDidacticos.getMaterialDidactico(oid);

            model.oid = oid;
            model.oidLista = md.oidLista;
            model.nome = md.nome;
            model.nrPaginas = md.nrPaginas;
            model.descricao = md.descricao;
            ViewBag.nomeDisciplina = md.Disciplina.nome;
            ViewBag.siglaCurso = md.ListaMaterialDidactico.CursoAno.oidSigla;
            ViewBag.anoLectivo = md.ListaMaterialDidactico.oidAnoLectivo;
            ViewBag.ano = md.ListaMaterialDidactico.CursoAno.ano;
            ViewBag.oid = oid;

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost,Authorize(Roles = "Estudante")]
        public ActionResult Index(MaterialModel model)
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            PedidosImpressao.insere(model.pedidoCor, model.pedidoFrenteVerso, model.pedidoNrCopias, model.pedidoPaginasFolha, estudante.oidUtilizador, model.oid);

            MaterialDidactico md = MateriaisDidacticos.getMaterialDidactico(model.oid);

            model.oidLista = md.oidLista;
            model.nome = md.nome;
            model.nrPaginas = md.nrPaginas;
            model.descricao = md.descricao;
            ViewBag.nomeDisciplina = md.Disciplina.nome;
            ViewBag.siglaCurso = md.ListaMaterialDidactico.CursoAno.oidSigla;
            ViewBag.anoLectivo = md.ListaMaterialDidactico.oidAnoLectivo;
            ViewBag.ano = md.ListaMaterialDidactico.CursoAno.ano;
            ViewBag.oid = model.oid;

            ViewBag.username = User.Identity.Name;

            return View(model);
        }


        [Authorize(Roles = "Administrador")]
        public ActionResult Add(int oid)
        {
            MaterialModel model = new MaterialModel();
            model.oidLista = oid;

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(MaterialModel model)
        {
            if (ModelState.IsValid)
            {
                MateriaisDidacticos.insere(model.descricao, model.nome, model.nrPaginas, model.oidDisciplina, model.oidLista);
                ListasMaterialDidactico.actualizaTime(model.oidLista);
                ViewBag.username = User.Identity.Name;
                return RedirectToAction("Editar", "ListasMaterial", new { oid = model.oidLista });
            }

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(int oid)
        {
            MaterialDidactico md = MateriaisDidacticos.getMaterialDidactico(oid);
            int oidLista = md.oidLista;
            MateriaisDidacticos.remove(oid);

            ViewBag.username = User.Identity.Name;

            return RedirectToAction("Editar", "ListasMaterial", new { oid = oidLista });
        }
    }
}
