﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class SearchController : Controller
    {
        //
        // GET: /Search/

        public JsonResult AutocompleteCursos(string term)
        {
            List<DescricaoCurso> listaCursos = DescricoesCurso.getAllCursosByTermo(term, 5);

            var data = from lc in listaCursos select new { label = lc.descricao, value = lc.sigla };

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AutocompleteDisciplinas(string term)
        {
            List<Disciplina> disciplinas = Disciplinas.getAllDisciplinasByTermo(term, 5);

            var data = from d in disciplinas select new { label = d.nome, value = d.oid };

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult AnosCurso(string sigla)
        {
            List<CursoAno> cursos = CursosAnos.getCursoAno(sigla);

            return Json(new SelectList(cursos, "oid", "ano"));
        }

    }
}
