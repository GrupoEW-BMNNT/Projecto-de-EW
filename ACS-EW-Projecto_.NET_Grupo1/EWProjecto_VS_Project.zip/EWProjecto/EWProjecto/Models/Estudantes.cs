﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Linq;
using System.Security.Cryptography;

namespace EWProjecto.Models
{
    public class Estudantes : ConexaoBD
    {
        public static List<Estudante> getEstudantesCursoAno(int id_cursoAno)
        {
            //obter todos os estudantes de um CursoAno
            return db.Estudantes.Where(e => e.oidCursoAno == id_cursoAno).ToList();
        }

        public static List<Estudante> getAllEstudantes()
        {
            // obter todos os estudantes
            return db.Estudantes.ToList();
        }

        public static Estudante getEstudante(int id)
        {
            //obter estudante através de id
            return db.Estudantes.SingleOrDefault(e => e.oidUtilizador == id);
        }

        public static Estudante getEstudante(string username)
        {
            //obter estudante através de username
            return db.Estudantes.SingleOrDefault(e => e.Utilizador.username == username);
        }

        public static string getPassword(string username)
        {
            //obterPassword de um estudante através do username
            return db.Estudantes.SingleOrDefault(e => e.Utilizador.username == username).Utilizador.password;
        }

        public static bool insere(string contacto, string email, int oidCursoAno, string password, string username)
        {
            if (Username_Exists(username) == false)
            {
                Utilizador u = new Utilizador();
                u.username = username;
                u.password = ComputeHash(password, new SHA512CryptoServiceProvider());
                db.Utilizadors.InsertOnSubmit(u);
                db.SubmitChanges();
                u = db.Utilizadors.SingleOrDefault(ut => ut.username == username); 

                Estudante e = new Estudante();
                e.oidUtilizador = u.oid;
                e.contacto = contacto;
                e.email = email;
                e.oidCursoAno = oidCursoAno;
                db.Estudantes.InsertOnSubmit(e);
                db.SubmitChanges();
                return true;
            }
            else return false;
        }

        public static void remove(string username)
        {
            Estudante e = db.Estudantes.SingleOrDefault(es => es.Utilizador.username == username);
            Utilizador u = db.Utilizadors.SingleOrDefault(ut => ut.username == username);
            db.Estudantes.DeleteOnSubmit(e);
            db.Utilizadors.DeleteOnSubmit(u);
            db.SubmitChanges();
        }

        public static void actualiza(string contacto, string email, int oidCursoAno, string password, string username)
        {
            //Model_W._data.Clientes.Attach(c);
            Estudante e = db.Estudantes.SingleOrDefault(es => es.Utilizador.username == username);
            if (e != null)
            {
                e.contacto = contacto;
                e.email = email;
                e.CursoAno = db.CursoAnos.Single(ca => ca.oid == oidCursoAno);
                e.Utilizador.password = ComputeHash(password, new SHA512CryptoServiceProvider());
                e.Utilizador.username = username;
                db.Refresh(RefreshMode.KeepCurrentValues, e);
                db.SubmitChanges();
            }
        }

        public static bool Username_Exists(string username)
        {
            //verificar se um username já existe
            return db.Estudantes.Where(e => e.Utilizador.username == username).Count() > 0;
        }

        public static string ComputeHash(string input, HashAlgorithm algorithm)
        {
            Byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
            Byte[] hashedBytes = algorithm.ComputeHash(inputBytes);
            return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
        }
    }
}