﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Linq;
using System.Security.Cryptography;

namespace EWProjecto.Models
{
    public class Utilizadores : ConexaoBD
    {
        public static List<Utilizador> getAllUtilizadores()
        {
            // obter todos os utilizadores
            return db.Utilizadors.ToList();
        }

        public static List<Utilizador> getAllOnlyUtilizadores()
        {
            // obter todos os administradores
            var onlyUsers = from u in db.Utilizadors    
                            where !(from e in db.Estudantes    
                                select e.oidUtilizador)    
                                .Contains(u.oid)    
                            select u;
            return onlyUsers.ToList();
        }

        public static Utilizador getUtilizador(string username)
        {
            //obter utilizador através de username
            return db.Utilizadors.SingleOrDefault(u => u.username == username);
        }

        public static Utilizador getUtilizador(int oid)
        {
            //obter utilizador através de oid
            return db.Utilizadors.SingleOrDefault(u => u.oid == oid);
        }

        public static bool insere(string username, string password)
        {
            if (Username_Exists(username) == false)
            {
                Utilizador u = new Utilizador();
                u.password = Estudantes.ComputeHash(password, new SHA512CryptoServiceProvider());
                u.username = username;
                db.Utilizadors.InsertOnSubmit(u);
                db.SubmitChanges();
                return true;
            }
            else return false;
        }

        public static void remove(string username)
        {
            Utilizador u = db.Utilizadors.SingleOrDefault(ut => ut.username == username);
            db.Utilizadors.DeleteOnSubmit(u);
            db.SubmitChanges();
        }

        public static void actualiza(string username, string password)
        {
            //Model_W._data.Clientes.Attach(c);
            Utilizador u = db.Utilizadors.SingleOrDefault(ut => ut.username == username);
            u.password = Estudantes.ComputeHash(password, new SHA512CryptoServiceProvider());
            u.username = username;
            db.Refresh(RefreshMode.KeepCurrentValues, u);
            db.SubmitChanges();
        }

        public static bool Username_Exists(string username)
        {
            //verificar se um username já existe
            return db.Utilizadors.Where(u => u.username == username).Count() > 0;
        }
    }
}