﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;

namespace EWProjecto.Models
{

    public class PedidosImpressao : ConexaoBD
    {

        public static PedidoImpressao getPedidoImpressao(int id)
        {
            //Obter um PedidoImpressao através do oid
            return db.PedidoImpressaos.SingleOrDefault(pi => pi.oid == id);
        }

        public static List<PedidoImpressao> getPedidoImpressaoEstudante(int idEstudante)
        {
            //Obter um PedidoImpressao através do oid de um estudante
            return db.PedidoImpressaos.Where(pi => pi.oidEstudante == idEstudante).OrderByDescending(pi => pi.adicionado).OrderBy(pi => pi.concluido).ToList();
        }

        public static List<PedidoImpressao> getPedidoImpressaoEstudante(int idEstudante, int estado) //true = concluido; false = cancelado; null = pendente
        {
            //Obter um PedidoImpressao através do oid de um estudante e de um estado
            List<PedidoImpressao> toReturn;
            switch (estado)
            {
                case 1 :
                    toReturn = db.PedidoImpressaos.Where(pi => pi.oidEstudante == idEstudante && pi.concluido == null).ToList();
                    break;
                case 2 :
                    toReturn = db.PedidoImpressaos.Where(pi => pi.oidEstudante == idEstudante && pi.concluido == true).ToList();
                    break;
                case 3 :
                    toReturn = db.PedidoImpressaos.Where(pi => pi.oidEstudante == idEstudante && pi.concluido == false).ToList();
                    break;
                default:
                    toReturn = db.PedidoImpressaos.Where(pi => pi.oidEstudante == idEstudante).OrderByDescending(pi => pi.adicionado).OrderBy(pi => pi.concluido).ToList();
                    break;
            }
            return toReturn;
        }

        public static List<PedidoImpressao> getPedidosImpressaoMaterial(int id_material)
        {
            //Obter todos os pedidos para um certo material
            return db.PedidoImpressaos.Where(pi => pi.oidMaterial == id_material).ToList();
        }

        public static List<PedidoImpressao> getAllPedidosImpressaoPendentes()
        {
            //Obter todos os pedidos de impressao pendentes
            return db.PedidoImpressaos.Where(pi => pi.concluido == null).OrderBy(pi => pi.adicionado).ToList();
        }

        public static MaterialDidactico getMaterialPedidoImpressao(int idPedido)
        {
            //Obter o Material de um determinado pedido
            return db.PedidoImpressaos.SingleOrDefault(pi => pi.oid == idPedido).MaterialDidactico;
        }

        public static void insere(bool cor, bool frenteVerso, int nrCopias, int pagPorFolha, int oidEstudante, int oidMaterial)
        {
            PedidoImpressao pi = new PedidoImpressao();
            pi.adicionado = DateTime.Now;
            pi.concluido = null;
            pi.cor = cor;
            double custoCor = db.Custos.SingleOrDefault(c => c.descricao == "cor").custo1;
            double custoPB = db.Custos.SingleOrDefault(c => c.descricao == "pb").custo1;
            double custo = cor ? custoCor : custoPB;
            int nrPaginas = db.MaterialDidacticos.SingleOrDefault(md => md.oid == oidMaterial).nrPaginas;
            pi.custo = nrPaginas*custo*nrCopias;
            pi.frenteVerso = frenteVerso;
            pi.nrCopias = nrCopias;
            pi.pagPorFolha = pagPorFolha;
            pi.oidEstudante = oidEstudante;
            pi.oidMaterial = oidMaterial;
            db.PedidoImpressaos.InsertOnSubmit(pi);
            db.SubmitChanges();
        }

        public static void remove(int oid)
        {
            PedidoImpressao pi = db.PedidoImpressaos.SingleOrDefault(pi2 => pi2.oid == oid);
            db.PedidoImpressaos.DeleteOnSubmit(pi);
            db.SubmitChanges();
        }

        public static void actualiza(int oid, bool cor, bool frenteVerso, int nrCopias, int pagPorFolha, int oidEstudante, int oidMaterial, bool? concluido)
        {
            //Model_W._data.PedidoImpressaos.Attach(pi);
            PedidoImpressao pi = db.PedidoImpressaos.SingleOrDefault(pi2 => pi2.oid == oid);
            pi.adicionado = DateTime.Now;
            pi.cor = cor;
            double custoCor = db.Custos.SingleOrDefault(c => c.descricao == "cor").custo1;
            double custoPB = db.Custos.SingleOrDefault(c => c.descricao == "pb").custo1;
            double custo = cor ? custoCor : custoPB;
            int nrPaginas = db.MaterialDidacticos.SingleOrDefault(md => md.oid == oidMaterial).nrPaginas;
            pi.custo = nrPaginas * custo * nrCopias;
            pi.frenteVerso = frenteVerso;
            pi.nrCopias = nrCopias;
            pi.pagPorFolha = pagPorFolha;
            pi.Estudante = db.Estudantes.Single(e => e.oidUtilizador == oidEstudante);
            pi.MaterialDidactico = db.MaterialDidacticos.Single(md => md.oid == oidMaterial);
            pi.concluido = concluido;
            db.Refresh(RefreshMode.KeepCurrentValues, pi);
            db.SubmitChanges();
        }

        public static void actualizaEstado(int oid, bool? concluido)
        {
            //Model_W._data.PedidoImpressaos.Attach(pi);
            PedidoImpressao pi = db.PedidoImpressaos.SingleOrDefault(pi2 => pi2.oid == oid);
            pi.adicionado = DateTime.Now;
            pi.concluido = concluido;
            db.Refresh(RefreshMode.KeepCurrentValues, pi);
            db.SubmitChanges();
        }
    }
}