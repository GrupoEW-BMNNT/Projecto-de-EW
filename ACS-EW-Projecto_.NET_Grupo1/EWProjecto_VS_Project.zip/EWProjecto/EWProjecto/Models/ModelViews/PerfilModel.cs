﻿using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Web.Mvc;

namespace EWProjecto.Models.ModelViews
{
    public class PerfilModel
    {
        [Required(ErrorMessage = "O username nao pode ser vazio")]
        [DisplayName("Username")]
        [DataType(DataType.Text)]
        public string username { get; set; }
        [Required(ErrorMessage = "A password nao pode ser vazia")]
        [DisplayName("Password")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        [Required(ErrorMessage = "O contacto nao pode ser vazio")]
        [DisplayName("Contacto")]
        [DataType(DataType.PhoneNumber)]
        public string contacto { get; set; }
        [Required(ErrorMessage = "O email nao pode ser vazio")]
        [DisplayName("E-mail")]
        [DataType(DataType.EmailAddress)]
        public string email { get; set; }
        [Required(ErrorMessage = "O curso nao pode ser vazio")]
        [DisplayName("Curso")]
        public string curso { get; set; }
        [DisplayName("Ano")]
        public int oidCurso { get; set; }
        public SelectList anosCurso { get; set; }

        public PerfilModel()
        {
            anosCurso = new SelectList(Enumerable.Empty<CursoAno>(), "oid", "ano");
        }
    }
}