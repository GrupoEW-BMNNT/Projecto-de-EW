﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;
using EWProjecto.Models.PaginatedClasses;

namespace EWProjecto.Models.ModelViews
{
    public class AnoLectivoModel
    {
        [Required(ErrorMessage = "O ano lectivo nao pode ser vazio")]
        [DisplayName("Ano lectivo")]
        public string anoLectivo { get; set; }
        public PaginatedAnosLectivos anosLectivos { get; set; }

        public AnoLectivoModel()
        {
            this.anosLectivos = new PaginatedAnosLectivos();
        }

        public AnoLectivoModel(IList<AnoLectivo> anosLectivos, int pageIndex)
        {
            this.anosLectivos = new PaginatedAnosLectivos(anosLectivos, pageIndex);
        }
    }
}