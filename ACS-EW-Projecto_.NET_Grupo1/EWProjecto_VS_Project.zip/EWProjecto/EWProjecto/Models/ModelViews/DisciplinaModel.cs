﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;
using EWProjecto.Models.PaginatedClasses;

namespace EWProjecto.Models.ModelViews
{
    public class DisciplinaModel
    {
        [Required(ErrorMessage = "O nome da disciplina nao pode ser vazio")]
        [DisplayName("Disciplina")]
        public string nome { get; set; }
        public PaginatedDisciplinas disciplinas { get; set; }

        public DisciplinaModel()
        {
            this.disciplinas = new PaginatedDisciplinas();
        }

        public DisciplinaModel(IList<Disciplina> disciplinas, int pageIndex)
        {
            this.disciplinas = new PaginatedDisciplinas(disciplinas, pageIndex);
        }
    }
}