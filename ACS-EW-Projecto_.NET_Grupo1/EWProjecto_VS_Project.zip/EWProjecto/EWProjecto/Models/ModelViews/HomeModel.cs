﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;
using System.Web.Mvc;

namespace EWProjecto.Models.ModelViews
{
    public class HomeModel : PaginatedList<ListaMaterialDidactico>
    {

        public HomeModel(IList<ListaMaterialDidactico> listas, int pageIndex)
            : base(listas, pageIndex, 10)
        {
        }
    }
}