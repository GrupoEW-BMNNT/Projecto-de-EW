﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;
using EWProjecto.Models.PaginatedClasses;

namespace EWProjecto.Models.ModelViews
{
    public class CursoModel
    {
        [Required(ErrorMessage="A descricao nao pode ser vazia")]
        [DisplayName("Descricao")]
        public string descricao { get; set; }
        [Required(ErrorMessage = "A sigla nao pode ser vazia")]
        [DisplayName("Sigla")]
        public string sigla { get; set; }
        public PaginatedCursos cursos { get; set; }

        public CursoModel()
        {
            this.cursos = new PaginatedCursos();
        }

        public CursoModel(IList<DescricaoCurso> cursos, int pageIndex)
        {
            this.cursos = new PaginatedCursos(cursos, pageIndex);
        }
    }
}