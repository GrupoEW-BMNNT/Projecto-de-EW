﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace EWProjecto.Models.ModelViews
{
    public class AnosCursoModel
    {
        [Required(ErrorMessage="O ano de curso nao pode estar vazio")]
        [DisplayName("Ano de curso")]
        public int anoCurso { get; set; }
        public string sigla { get; set; }

        public AnosCursoModel(string sigla){
            this.sigla = sigla;
        }
        public AnosCursoModel()
        {
        }

    }
}