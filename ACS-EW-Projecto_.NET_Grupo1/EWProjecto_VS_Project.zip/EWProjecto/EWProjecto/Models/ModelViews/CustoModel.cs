﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace EWProjecto.Models.ModelViews
{
    public class CustoModel
    {
        [Required(ErrorMessage="A descricao nao pode ser vazia")]
        [DisplayName("Descricao")]
        public string descricao { get; set; }
        [Required(ErrorMessage = "O custo nao pode ser vazio")]
        [DisplayName("Custo")]
        public double custo { get; set; }

        public CustoModel()
        {
        }
    }
}