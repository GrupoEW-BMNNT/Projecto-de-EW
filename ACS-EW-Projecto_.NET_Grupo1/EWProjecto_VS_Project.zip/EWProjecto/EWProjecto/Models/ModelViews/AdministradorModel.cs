﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;
using EWProjecto.Models.PaginatedClasses;

namespace EWProjecto.Models.ModelViews
{
    public class AdministradorModel
    {
        [Required(ErrorMessage = "O username nao pode ser vazio")]
        [DisplayName("Username")]
        public string username { get; set; }
        [Required(ErrorMessage = "A password nao pode ser vazia")]
        [DisplayName("Password")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        public PaginatedAdmins administradores { get; set; }

        public AdministradorModel()
        {
            this.administradores = new PaginatedAdmins();
        }

        public AdministradorModel(IList<Utilizador> administradores, int pageIndex)
        {
            this.administradores = new PaginatedAdmins(administradores, pageIndex);
        }
    }
}