﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;
using System.Web.Security;


namespace EWProjecto.Models.Testing
{
    public class Populate
    {
        public static void Popular()
        {
            populateCursos();
            populateAnos();
            populateDisciplinas();
            populateAnosLectivos();
            pouplateCustos();
            populateListaMaterial();
            populateMaterial();
            populateGrupos();
            populateEstudantes();
            populateAdministrador();
            populatePedidosImpressao();
        }

        private static void populatePedidosImpressao()
        {
            List<Estudante> estudantes = Estudantes.getAllEstudantes();
            string[] anosLectivos = { "2011-2012", "2012-2013" };
            Random random = new Random();

            foreach (Estudante e in estudantes)
            {
                List<MaterialDidactico> materialCursoAno1 = MateriaisDidacticos.getMaterialDidaticoCursoAno(e.oidCursoAno).Where(m => m.ListaMaterialDidactico.oidAnoLectivo == anosLectivos[0]).ToList();
                List<MaterialDidactico> materialCursoAno2 = MateriaisDidacticos.getMaterialDidaticoCursoAno(e.oidCursoAno).Where(m => m.ListaMaterialDidactico.oidAnoLectivo == anosLectivos[1]).ToList();

                int percentagemPedidos = (int) (((double) materialCursoAno2.Count) * 0.66d);
                int numPedidosAGerarAno2 = random.Next(0, percentagemPedidos);
                int numPedidosAGerarAno1 = numPedidosAGerarAno2 / 3;

                for (int i = 0; i < numPedidosAGerarAno2; i++)
                {
                    MaterialDidactico material = materialCursoAno2.ElementAt(random.Next(0, materialCursoAno2.Count));
                    PedidosImpressao.insere(false, true, random.Next(1, 3), 2, e.oidUtilizador, material.oid);
                }

                for (int i = 0; i < numPedidosAGerarAno1; i++)
                {
                    MaterialDidactico material = materialCursoAno1.ElementAt(random.Next(0, materialCursoAno1.Count));
                    PedidosImpressao.insere(true, true, random.Next(1, 2), 1, e.oidUtilizador, material.oid);
                }

                List<PedidoImpressao> pedidosEstudante = PedidosImpressao.getPedidoImpressaoEstudante(e.oidUtilizador);
                foreach (PedidoImpressao pedido in pedidosEstudante)
                {
                    int tipo = random.Next(0, 100);
                    if (tipo > 0 && tipo <= 60) { PedidosImpressao.actualizaEstado(pedido.oid, null); }
                    else if (tipo > 60 && tipo <= 90) { PedidosImpressao.actualizaEstado(pedido.oid, true); }
                    else { PedidosImpressao.actualizaEstado(pedido.oid, false); }
                }
            }
        }

        private static void populateGrupos()
        {
            string[] nomes = { "Estudante", "Administrador" };

            foreach (string nome in nomes)
            {
                Groups.insere(nome);
            }
        }

        private static void populateAdministrador()
        {
            string username = "admin";
            string password = "admin";
            Utilizadores.insere(username, password);

            if (!Roles.IsUserInRole(username, "Administrador"))
            {
                Roles.AddUserToRole(username, "Administrador");
            }
        }

        private static void populateEstudantes()
        {
            string[] siglas = { "MEI", "MIEMec", "MIEBiol", "MBionfCB", "LCC", "LDir", "MRSCom", "MIEGI", "MIEMat", "LEI" };
            int[] anosCurso = { 2, 5, 5, 2, 3, 4, 2, 5, 5, 3 };
            Random random = new Random();

            int numEstudantesAGerar = random.Next(3, 6);

            for (int i = 0; i < numEstudantesAGerar; i++)
            {
                int numCurso = random.Next(0, siglas.Length);
                int numAnoCurso = random.Next(0, anosCurso[numCurso])+1;
                string contacto = "910 019 091";
                string email = "user" + i + "@ccum.pt";
                string username = "user" + i;
                string password = username;
                CursoAno ca = CursosAnos.getCursoAnoByAnoSigla(numAnoCurso, siglas[numCurso]);
                Estudantes.insere(contacto, email, ca.oid, password, username);

                if (!Roles.IsUserInRole(username, "Estudante"))
                {
                    Roles.AddUserToRole(username, "Estudante");
                }
            }
        }

        private static void populateMaterial()
        {
            populateMaterialMEI();
            populateMaterialMIEMec();
            populateMaterialMIEBiol();
            populateMaterialMBionfCB();
            populateMaterialLCC();
            populateMaterialLDir();
            populateMaterialMIEC();
            populateMaterialMRSCom();
            populateMaterialMIEGI();
            populateMaterialMIEMat();
            populateMaterialLEI();
        }

        private static string getNomeMaterial()
        {
            Random random = new Random();
            int valor = random.Next(0, 100);

            if (valor >= 0 && valor < 30)
            {
                return "Exercicios";
            }
            else if (valor >= 30 && valor < 60)
            {
                return "Slides";
            }
            else if (valor >= 60 && valor < 90)
            {
                return "Apontamentos";
            }
            else
            {
                return "Livro";
            }
        }
        private static string getDescricaoMaterial(string nome)
        {
            Random random = new Random();
            string aula = random.Next(1, 14).ToString();
            switch (nome)
            {
                case "Exercicios":
                    return "Exercicios resolvidos na aula " + aula;
                case "Slides":
                    return "Slides teóricos da aula " + aula;
                case "Apontamentos":
                    return "Apontamentos tirados na aula " + aula;
                case "Livro":
                    return "Livro de apoio";
                default:
                    return "Comum";
            }
        }
        private static int getNrPaginas(string nome)
        {
            Random random = new Random();
            switch (nome)
            {
                case "Exercicios":
                    return random.Next(1, 5);
                case "Slides":
                    return random.Next(1, 40);
                case "Apontamentos":
                    return random.Next(1, 10);
                case "Livro":
                    return random.Next(20, 200);
                default:
                    return random.Next(1, 50);
            }
        }

        private static void populateMaterialAux(List<string[]> disciplinas, string sigla)
        {
            Random random = new Random();
            List<CursoAno> listaAnos = CursosAnos.getCursoAno(sigla);

            foreach (CursoAno anoCurso in listaAnos)
            {
                List<ListaMaterialDidactico> listas = ListasMaterialDidactico.getListaMaterialDidacticoCursoAno(anoCurso.oid);
                foreach (ListaMaterialDidactico lista in listas)
                {
                    int numMaterialAGerar = random.Next(15, 30);
                    for (int i = 0; i < numMaterialAGerar; i++)
                    {
                        string nome = getNomeMaterial();
                        string descricao = getDescricaoMaterial(nome);
                        int nrPaginas = getNrPaginas(nome);
                        int ano = random.Next(0, disciplinas.Count);
                        string[] disciplinasAno = disciplinas.ElementAt(ano);
                        string disciplina = disciplinasAno[random.Next(0, disciplinasAno.Length)];
                        Disciplina d = Disciplinas.getDisciplina(disciplina);
                        MateriaisDidacticos.insere(descricao, nome, nrPaginas, d.oid, lista.oid);
                    }
                }
            }
        }

        private static void populateMaterialLEI()
        {
            string[] ano1 = { "Álgebra Linear EI", "Cálculo", "Elementos de Engenharia de Sistemas", "Laboratórios de Informática I", "Programação Funcional", "Tópicos de Matemática Discreta", "Análise", "Laboratórios de Informática II", "Lógica EI", "Programação Imperativa", "Sistemas de Computação", "Tópicos de Física Moderna" };
            string[] ano2 = { "Algoritmos e Complexidade", "Arquitetura de Computadores", "Comunicação de Dados", "Engenharia Económica", "Estatística Aplicada", "Introdução aos Sistemas Dinâmicos", "Cálculo de Programas", "Electromagnetismo EE", "Laboratórios de Informática III", "Programação Orientada aos Objetos", "Sistemas Operativos", "Cérebro e Comportamento", "Corpo, Género e Sexualidade", "Escrita Académica", "Ética: As Grandes Questões do Nosso Tempo", "Inglês Académico", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês", "Língua Estrangeira Nível 1 - Italiano", "Matemática das Coisas", "Ótica na Natureza, Fotografia e Cinema 3D" };
            string[] ano3 = { "Bases de Dados", "Desenvolvimento de Sistemas de Software", "Métodos Numéricos e Otimização Não Linear", "Modelos Determinísticos de Investigação Operacional", "Redes de Computadores", "Sistemas Distribuídos", "Computação Gráfica", "Comunicações por Computador", "Laboratórios de Informática IV", "Modelos Estocásticos de Investigação Operacional", "Processamento de Linguagens", "Sistemas de Representação de Conhecimento e Raciocínio" };
            string[] anosLectivos = { "2008-2009", "2009-2010", "2010-2011", "2011-2012", "2012-2013" };
            string sigla = "LEI";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMIEMat()
        {
            string[] ano1 = { "Álgebra Linear EE", "Algoritmia e Programação", "Cálculo EE", "Ciência de Materiais", "Desenho e Métodos Gráficos", "Química Geral EE", "Análise Matemática EE", "Ciência de Polímeros I", "Comportamento Mecânico de Materiais I", "Diagramas de Fases", "Física EE", "Laboratório Integrado 1" };
            string[] ano2 = { "Ciência de Polímeros II", "Complementos de Análise Matemática EE", "Comportamento Mecânico de Materiais II", "Electromagnetismo EE", "Estrutura Atómica e Molecular", "Laboratório Integrado 2", "Estatística Aplicada", "Física de Polímeros", "Física dos Materiais", "Laboratório Integrado 3", "Metalurgia Química", "Métodos Numéricos" };
            string[] ano3 = { "Fundamentos de Transferência de Calor", "Laboratório Integrado 4", "Materiais Cerâmicos e Vidros", "Metalurgia Física", "Processamento de Polímeros I", "Reologia", "Composição e Modificação de Polímeros", "Laboratório Integrado 5", "Materiais e Ambiente", "Processamento de Cerâmicos", "Propriedades Eletrónicas dos Materiais", "Tratamentos Térmicos" };
            string[] ano4 = { "egradação de Materiais", "Eletrónica e Instrumentação", "Laboratório Integrado 6", "Materiais Nanoestruturados", "Tecnologia de Vácuo", "Tecnologias de Fundição e Soldadura", "Ciência e Tecnologia de Filmes Finos", "Processamento de Polímeros II", "Projeto Individual", "Seleção e Aplicação de Materiais", "Tecnologias de Maquinagem e Conformação" };
            string[] ano5 = { "Dissertação em Engenharia de Materiais", "Criação e Organização de Empresas", "Materiais Compósitos", "Micro e Nanotecnologias", "Tratamento de Resíduos e Reciclagem de Metais", "Análise de Dados com Software Estatístico: SPSS e R", "Catástrofes Naturais", "Educação, Cidadania e Direitos Humanos", "Inglês Académico", "Leitura e Escrita para a Produção de Conhecimento Académico", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês", "Ótica na Natureza, Fotografia e Cinema 3D" };
            string sigla = "MIEMat";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);
            disciplinas.Add(ano4);
            disciplinas.Add(ano5);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMIEGI()
        {
            string[] ano1 = { "Álgebra Linear EE", "Algoritmia e Programação", "Cálculo EE", "Introdução à Engenharia e Gestão Industrial", "Projeto Integrado em Engenharia e Gestão Industrial I", "Química Geral EE", "Ambientes e Contextos de Programação", "Análise de Custos", "Análise Matemática EE", "Estatística Aplicada", "Física EE", "Introdução à Engenharia Económica" };
            string[] ano2 = { "Complementos de Análise Matemática EE", "Complementos de Estatística", "Electromagnetismo EE", "Gestão de Custos", "Tecnologias de Bases de Dados", "Termodinâmica e Mecânica dos Fluídos", "Eletrotecnia e Eletrónica", "Investigação Operacional", "Métodos Numéricos", "Ciência de Materiais", "Desenho Técnico e Fabrico com Metais", "Desenho Técnico e Produção de Produtos Filiformes", "Desenvolvimento Psicológico, Comportamento e Contextos de Vida", "Educação, Cidadania e Direitos Humanos", "Geografia Cultural e Contemporânea", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês" };
            string[] ano3 = { "Controlo de Processos e Automação", "Energia, Ambiente e Instalações Industriais", "Engenharia e Gestão da Qualidade", "Modelos Estocásticos de Investigação Operacional", "Organização de Sistemas de Produção I", "Processamento e Projeto com Plásticos", "Tecnologias de Produção na Confeção", "Análise de Projetos", "Ergonomia e Estudo do Trabalho", "Logística", "Modelos de Decisão", "Planeamento e Controlo da Produção", "Segurança e Higiene Ocupacionais" };
            string[] ano4 = { "Estudo Ergonómico de Postos de Trabalho", "Gestão Integrada da Produção", "Organização de Sistemas de Produção II", "Projeto Integrado em Engenharia e Gestão Industrial II", "Simulação", "Sistemas de Informação para a Produção", "CAD/CAPP", "Complementos de Engenharia e Gestão da Qualidade", "Fabrico Assistido por Computador", "Fiabilidade e Manutenção", "Projeto Integrado em Engenharia e Gestão Industrial III", "Sociologia e Direito das Organizações" };
            string[] ano5 = { "Métodos de Investigação", "Gestão da Cadeia de Abastecimento", "Gestão da Inovação", "Estratégia e Custos", "Projeto de Sistemas de Produção Orientados ao Produto", "Desenvolvimento de Novos Produtos", "Sistemas de Controlo da Atividade Produtiva", "Dissertação em Engenharia e Gestão Industrial" };
            string sigla = "MIEGI";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);
            disciplinas.Add(ano4);
            disciplinas.Add(ano5);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMRSCom()
        {
            string[] ano1 = { "Engenharia de Redes e Serviços", "Tecnologias e Protocolos de Infraestrutura" };
            string[] ano2 = { "Engenharia de Tráfego" };
            string sigla = "MRSCom";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMIEC()
        {
            string[] ano1 = { "Álgebra Linear e Geometria Analitica A", "Cálculo A", "Ciência dos Materiais de Construção", "Informática A", "Introdução à Engenharia e Técnicas de Representação", "Análise Matemática A", "Desenho e Elementos de Arquitectura", "Física B", "Mecânica das Estruturas", "Métodos Numéricos D" };
            string[] ano2 = { "Complementos de Análise Matemática A", "Electromagnetismo B", "Materiais de Construção I", "Métodos Estatísticos A", "Resistência dos Materiais I", "Geologia de Engenharia Civil", "Investigação Operacional", "Materiais de Construção II", "Organização e Gestão da Construção I", "Resistência dos Materiais II", "Topografia" };
            string[] ano3 = { "Análise de Estruturas I", "Física das Construções", "Hidráulica Geral I", "Organização e Gestão da Construção II", "Vias de Comunicação I", "Análise de Estruturas II", "Geotecnia I", "Hidráulica Geral II", "Planeamento Territorial", "Vias de Comunicação II" };
            string[] ano4 = { "Estruturas de Betão I", "Geotecnia II", "Hidráulica Urbana", "Planeamento Urbano", "Tecnologia das Construções", "Estruturas de Betão II", "Hidrologia Aplicada", "Instalações das Construções" };
            string[] ano5 = { "Construção Sustentável", "Qualidade, Segurança e Ambiente", "Seminário", "Inovação Tecnológica da Construção", "Comportamento Termo-energético de Edifícios", "Complementos de Materiais de Construção I", "Projeto" };
            string sigla = "MIEC";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);
            disciplinas.Add(ano4);
            disciplinas.Add(ano5);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialLDir()
        {
            string[] ano1 = { "Direito Constitucional", "História do Direito", "Introdução ao Estudo do Direito", "Economia Política", "Filosofia Política", "Metodologia do Direito", "Direito Comparado", "Língua Estrangeira: Alemão Jurídico", "Língua Estrangeira: Inglês Jurídico" };
            string[] ano2 = { "Direito Administrativo", "Teoria Geral do Direito Civil", "Direito Internacional Público", "Finanças Públicas", "Direito Comunitário", "Direito Fiscal I", "Criminologia" };
            string[] ano3 = { "Direito das Obrigações", "Direito Penal I", "Direito Processual Civil-Declaratório", "Direito Fiscal II", "Direitos Reais", "Direito Processual Administrativo" };
            string[] ano4 = { "Direito Comercial", "Direito da Família e Sucessões", "Direito do Trabalho", "Direito Penal II", "Direito Processual Civil-Executivo", "Direito Internacional Privado", "Direito Processual Penal", "Direitos Fundamentais" };
            string sigla = "LDir";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);
            disciplinas.Add(ano4);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialLCC()
        {
            string[] ano1 = { "Álgebra Linear CC", "Cálculo", "Programação Funcional", "Tópicos de Matemática", "Bioética", "Comunicação, Ciência e Ambiente", "Desenvolvimento Psicológico, Comportamento e Contextos de Vida", "Educação, Cidadania e Direitos Humanos", "Energia e Ambiente", "Escrita Académica", "Gestão do Conhecimento e da Inovação", "Introdução aos Estudos Históricos", "Liderança e Empreendedorismo", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Espanhol", "Língua Estrangeira Nível 1 - Francês", "Língua Estrangeira Nível 1 - Italiano", "Língua Estrangeira Nível 1 - Russo", "Psicologia, Ciências Cognitivas e Comportamento", "Serviços de Informação de Apoio à Comunidade Científica", "Análise", "Geometria", "Laboratório de Algoritmia I", "Matemática Discreta", "Programação Imperativa", "Sistemas de Computação" };
            string[] ano2 = { "Álgebra", "Algoritmos e Complexidade", "Análise Numérica", "Lógica CC", "Sistemas de Comunicações e Redes", "Análise", "Cálculo de Programas", "Geometria", "Laboratório de Algoritmia II", "Programação Orientada aos Objetos", "Sistemas Operativos" };
            string[] ano3 = { "Análise Numérica", "Bases de Dados", "Computabilidade", "Probabilidades e Aplicações", "Programação Concorrente", "Computação Gráfica", "Geometria", "Processos e Concorrência", "Semântica da Programação", "Teoria de Números Computacional" };
            string sigla = "LCC";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMBionfCB()
        {
            string[] ano1 = { "Algoritmos para Análise de Sequências Biológicas", "Biologia de Sistemas", "Biologia Molecular e Celular", "Engenharia Bioquímica", "Laboratórios de Bioinformática", "Métodos Estatísticos para a Bioinformática", "Algoritmos Avançados de Bioinformática", "Engenharia Genética", "Extração de Conhecimento de Bases de Dados Biológicos", "Modelação de Processos Biológicos", "Projeto de Bioinformática e Biologia de Sistemas" };
            string[] ano2 = { "Dissertação em Bioinformática", "Empreeendedorismo em Biotecnologia e Bioinformática", "Métodos de Investigação em Bioinformática", "Sistemas Inteligentes para a Bioinformática" };
            string sigla = "MBionfCB";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMIEBiol()
        {
            string[] ano1 = { "Álgebra Linear EE", "Cálculo EE", "Computação e Programação", "Laboratórios Integrados de Química", "Química Analítica", "Sistemas de Representação Gráfica", "Análise Matemática EE", "Biologia Celular e Molecular", "Física EE", "Introdução à Engenharia de Processo", "Laboratórios Integrados de Física", "Química Orgânica EE" };
            string[] ano2 = { "Complementos de Análise Matemática EE", "Electromagnetismo EE", "Fenómenos de Transferência I", "Física EE", "Laboratórios Integrados de Biologia", "Microbiologia", "Termodinâmica Química", "Bioquímica e Fisiologia Microbianas", "Fenómenos de Transferência II", "Laboratórios de Fenómenos de Transferência", "Métodos Estatísticos EE", "Métodos Numéricos", "Química-Física" };
            string[] ano3 = { "Biologia Molecular Aplicada", "Engenharia da Reação Química I", "Engenharia dos Sistemas Processuais", "Engenharia Enzimática", "Laboratórios de Tecnologia Química", "Processos de Separação I", "Engenharia Bioquímica", "Engenharia da Reação Química II", "Engenharia Económica", "Laboratórios de Bioprocessos", "Processos de Separação II", "Tópicos Complementares" };
            string[] ano4 = { "Elementos de Engenharia do Ambiente", "Elementos de Qualidade e Fiabilidade", "Estratégia em Engenharia de Processo", "Laboratórios de Tecnologia Ambiental", "Tratamento de Água e Efluentes Líquidos", "Controlo e Instrumentação de Processos", "Gestão Ambiental", "Poluição do Ar", "Projeto em Engenharia de Processo", "Tratamento de Resíduos Sólidos" };
            string[] ano5 = { "Projeto Individual em Engenharia Biológica", "Produtos e Processos Limpos", "Tecnologias Ambientais", "Biotecnologia Molecular", "Enologia", "Bioinformática e Biologia de Sistemas", "Energia e Ambiente", "Inovação e Empreendedorismo em Biotecnologia e Bioinformática", "Bioética", "Catástrofes Naturais", "Comunicação, Ciência e Ambiente", "Desenvolvimento Psicológico, Comportamento e Contextos de Vida", "Educação, Cidadania e Direitos Humanos", "Escrita Académica", "Gestão do Conhecimento e da Inovação", "Introdução aos Estudos Históricos", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Espanhol", "Língua Estrangeira Nível 1 - Francês", "Língua Estrangeira Nível 1 - Italiano", "Língua Estrangeira Nível 1 - Russo", "Matemática das Coisas", "Moléculas, Cultura e Sociedade", "Psicologia, Ciências Cognitivas e Comportamento", "Dissertação em Engenharia Biológica" };
            string sigla = "MIEBiol";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);
            disciplinas.Add(ano4);
            disciplinas.Add(ano5);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMIEMec()
        {
            string[] ano1 = { "Álgebra Linear EE", "Cálculo EE", "Ciência e Tecnologia dos Materiais", "Desenho e Métodos Gráficos", "Electromagnetismo EE", "Integradora I", "Algoritmia e Programação", "Análise Matemática EE", "Desenho e Modelação Assistidos por Computador", "Integradora II", "Mecânica Geral", "Metalurgia Mecânica" };
            string[] ano2 = { "Complementos de Análise Matemática EE", "Eletrotecnia e Eletrónica", "Estatística Aplicada", "Integradora III", "Mecânica dos Materiais I", "Termodinâmica", "Automação Industrial", "Integradora IV", "Mecânica dos Fluidos", "Mecânica dos Materiais II", "Métodos Numéricos", "Tecnologias de Maquinagem e Conformação" };
            string[] ano3 = { "Especificação e Comando de Sistemas a Eventos Discretos", "Integradora V", "Órgãos de Máquinas I", "Técnicas de CAM/CAE", "Tecnologias de Fundição e Soldadura", "Transferência de Calor", "Energética Industrial", "Integradora VI", "Mecânica Computacional", "Órgãos de Máquinas II", "Teoria do Projeto Mecânico", "Tribologia" };
            string[] ano4 = { "Avaliação Económica de Projetos", "Controlo de Processos", "Integradora VII", "Máquinas Térmicas e Fluidos", "Tratamentos Térmicos", "Conceção de Estruturas", "Energia e Ambiente", "Tecnologias da Manufatura", "Complementos de Física", "Integradora VIII", "Organização e Gestão da Produção" };
            string[] ano5 = { "Dissertação em Engenharia Mecânica", "Análise de Dados com Software Estatístico: SPSS e R", "Catástrofes Naturais", "Educação, Cidadania e Direitos Humanos", "Inglês Académico", "Leitura e Escrita para a Produção de Conhecimento Académico", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês", "Ótica na Natureza, Fotografia e Cinema 3D", "Gestão da Atividade Industrial" };
            string sigla = "MIEMec";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);
            disciplinas.Add(ano3);
            disciplinas.Add(ano4);
            disciplinas.Add(ano5);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateMaterialMEI()
        {
            string[] ano1 = { "Análise e Conceção de Software", "Bioinformática", "Computação Gráfica", "Computação Paralela Distribuída", "Criptografia e Segurança de Sistemas de Informação", "Engenharia de Aplicações", "Engenharia de Linguagens", "Engenharia de Redes de Computadores", "Engenharia de Serviços de Comunicações e Sistemas Ubíquos", "Métodos Formais em Engenharia de Software", "Sistemas de Suporte à Decisão", "Sistemas Distribuídos", "Sistemas Inteligentes" };
            string[] ano2 = { "Dissertação", "Seminário" };
            string sigla = "MEI";
            List<string[]> disciplinas = new List<string[]>();
            disciplinas.Add(ano1);
            disciplinas.Add(ano2);

            populateMaterialAux(disciplinas, sigla);
        }

        private static void populateListaMaterial()
        {
            string[] cursos = { "Mestrado em Engenharia Informática", "Mestrado Integrado em Engenharia Mecânica", "Mestrado Integrado em Engenharia Biológica", "Mestrado em Bioinformática - Ciências Biológicas", "Licenciatura em Ciências da Computação", "Licenciatura em Direito", "Mestrado em Redes e Serviços de Comunicações", "Mestrado Integrado em Engenharia e Gestão Industrial", "Mestrado Integrado em Engenharia de Materiais", "Licenciatura em Engenharia Informática" };
            string[] siglas = { "MEI", "MIEMec", "MIEBiol", "MBionfCB", "LCC", "LDir", "MRSCom", "MIEGI", "MIEMat" , "LEI"};
            int[] anosCurso = { 2, 5, 5, 2, 3, 4, 2, 5, 5, 3 };
            string[] anosLectivos = { "2008-2009", "2009-2010", "2010-2011", "2011-2012", "2012-2013" };
            string descricao1 = "Lista de material do ano lectivo ";
            string descricao2 = " do curso ";

            for (int i = 0; i < cursos.Length; i++)
            {
                for (int j = 0; j < anosCurso[i]; j++)
                {
                    CursoAno c = CursosAnos.getCursoAnoByAnoSigla(j + 1, siglas[i]);
                    for (int k = 0; k < anosLectivos.Length; k++)
                    {
                        string descricao = descricao1 + anosLectivos[k] + descricao2 + cursos[i] + ".";
                        ListasMaterialDidactico.insere(descricao, anosLectivos[k], c.oid);
                    }
                }
            }
        }

        private static void pouplateCustos()
        {
            Costs.insere("pb", 0.02d);
            Costs.insere("cor", 0.16d);
        }

        private static void populateDisciplinas()
        {
            populateDisciplinasMEI();
            populateDisciplinasMIEMec();
            populateDisciplinasMIEBiol();
            populateDisciplinasMBionfCB();
            populateDisciplinasLCC();
            populateDisciplinasLDir();
            populateDisciplinasMIEC();
            populateDisciplinasMRSCom();
            populateDisciplinasMIEGI();
            populateDisciplinasMIEMat();
            populateDisciplinasLEI();
        }

        private static void populateDisciplinasAux(string[] disciplinas)
        {
            foreach (string disciplina in disciplinas)
            {
                Disciplinas.insere(disciplina);
            }
        }

        private static void populateDisciplinasLEI()
        {
            string[] ano1 = { "Álgebra Linear EI", "Cálculo", "Elementos de Engenharia de Sistemas", "Laboratórios de Informática I", "Programação Funcional", "Tópicos de Matemática Discreta", "Análise", "Laboratórios de Informática II", "Lógica EI", "Programação Imperativa", "Sistemas de Computação", "Tópicos de Física Moderna" };
            string[] ano2 = { "Algoritmos e Complexidade", "Arquitetura de Computadores", "Comunicação de Dados", "Engenharia Económica", "Estatística Aplicada", "Introdução aos Sistemas Dinâmicos", "Cálculo de Programas", "Electromagnetismo EE", "Laboratórios de Informática III", "Programação Orientada aos Objetos", "Sistemas Operativos", "Cérebro e Comportamento", "Corpo, Género e Sexualidade", "Escrita Académica", "Ética: As Grandes Questões do Nosso Tempo", "Inglês Académico", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês", "Língua Estrangeira Nível 1 - Italiano", "Matemática das Coisas", "Ótica na Natureza, Fotografia e Cinema 3D" };
            string[] ano3 = { "Bases de Dados", "Desenvolvimento de Sistemas de Software", "Métodos Numéricos e Otimização Não Linear", "Modelos Determinísticos de Investigação Operacional", "Redes de Computadores", "Sistemas Distribuídos", "Computação Gráfica", "Comunicações por Computador", "Laboratórios de Informática IV", "Modelos Estocásticos de Investigação Operacional", "Processamento de Linguagens", "Sistemas de Representação de Conhecimento e Raciocínio" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
        }

        private static void populateDisciplinasMIEMat()
        {
            string[] ano1 = { "Álgebra Linear EE", "Algoritmia e Programação", "Cálculo EE", "Ciência de Materiais", "Desenho e Métodos Gráficos", "Química Geral EE", "Análise Matemática EE", "Ciência de Polímeros I", "Comportamento Mecânico de Materiais I", "Diagramas de Fases", "Física EE", "Laboratório Integrado 1" };
            string[] ano2 = { "Ciência de Polímeros II", "Complementos de Análise Matemática EE", "Comportamento Mecânico de Materiais II", "Electromagnetismo EE", "Estrutura Atómica e Molecular", "Laboratório Integrado 2", "Estatística Aplicada", "Física de Polímeros", "Física dos Materiais", "Laboratório Integrado 3", "Metalurgia Química", "Métodos Numéricos" };
            string[] ano3 = { "Fundamentos de Transferência de Calor", "Laboratório Integrado 4", "Materiais Cerâmicos e Vidros", "Metalurgia Física", "Processamento de Polímeros I", "Reologia", "Composição e Modificação de Polímeros", "Laboratório Integrado 5", "Materiais e Ambiente", "Processamento de Cerâmicos", "Propriedades Eletrónicas dos Materiais", "Tratamentos Térmicos" };
            string[] ano4 = { "egradação de Materiais", "Eletrónica e Instrumentação", "Laboratório Integrado 6", "Materiais Nanoestruturados", "Tecnologia de Vácuo", "Tecnologias de Fundição e Soldadura", "Ciência e Tecnologia de Filmes Finos", "Processamento de Polímeros II", "Projeto Individual", "Seleção e Aplicação de Materiais", "Tecnologias de Maquinagem e Conformação" };
            string[] ano5 = { "Dissertação em Engenharia de Materiais", "Criação e Organização de Empresas", "Materiais Compósitos", "Micro e Nanotecnologias", "Tratamento de Resíduos e Reciclagem de Metais", "Análise de Dados com Software Estatístico: SPSS e R", "Catástrofes Naturais", "Educação, Cidadania e Direitos Humanos", "Inglês Académico", "Leitura e Escrita para a Produção de Conhecimento Académico", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês", "Ótica na Natureza, Fotografia e Cinema 3D" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
            populateDisciplinasAux(ano4);
            populateDisciplinasAux(ano5);
        }

        private static void populateDisciplinasMIEGI()
        {
            string[] ano1 = { "Álgebra Linear EE", "Algoritmia e Programação", "Cálculo EE", "Introdução à Engenharia e Gestão Industrial", "Projeto Integrado em Engenharia e Gestão Industrial I", "Química Geral EE", "Ambientes e Contextos de Programação", "Análise de Custos", "Análise Matemática EE", "Estatística Aplicada", "Física EE", "Introdução à Engenharia Económica" };
            string[] ano2 = { "Complementos de Análise Matemática EE", "Complementos de Estatística", "Electromagnetismo EE", "Gestão de Custos", "Tecnologias de Bases de Dados", "Termodinâmica e Mecânica dos Fluídos", "Eletrotecnia e Eletrónica", "Investigação Operacional", "Métodos Numéricos", "Ciência de Materiais", "Desenho Técnico e Fabrico com Metais", "Desenho Técnico e Produção de Produtos Filiformes", "Desenvolvimento Psicológico, Comportamento e Contextos de Vida", "Educação, Cidadania e Direitos Humanos", "Geografia Cultural e Contemporânea", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês" };
            string[] ano3 = { "Controlo de Processos e Automação", "Energia, Ambiente e Instalações Industriais", "Engenharia e Gestão da Qualidade", "Modelos Estocásticos de Investigação Operacional", "Organização de Sistemas de Produção I", "Processamento e Projeto com Plásticos", "Tecnologias de Produção na Confeção", "Análise de Projetos", "Ergonomia e Estudo do Trabalho", "Logística", "Modelos de Decisão", "Planeamento e Controlo da Produção", "Segurança e Higiene Ocupacionais" };
            string[] ano4 = { "Estudo Ergonómico de Postos de Trabalho", "Gestão Integrada da Produção", "Organização de Sistemas de Produção II", "Projeto Integrado em Engenharia e Gestão Industrial II", "Simulação", "Sistemas de Informação para a Produção", "CAD/CAPP", "Complementos de Engenharia e Gestão da Qualidade", "Fabrico Assistido por Computador", "Fiabilidade e Manutenção", "Projeto Integrado em Engenharia e Gestão Industrial III", "Sociologia e Direito das Organizações" };
            string[] ano5 = { "Métodos de Investigação", "Gestão da Cadeia de Abastecimento", "Gestão da Inovação", "Estratégia e Custos", "Projeto de Sistemas de Produção Orientados ao Produto", "Desenvolvimento de Novos Produtos", "Sistemas de Controlo da Atividade Produtiva", "Dissertação em Engenharia e Gestão Industrial" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
            populateDisciplinasAux(ano4);
            populateDisciplinasAux(ano5);

        }

        private static void populateDisciplinasMRSCom()
        {
            string[] ano1 = { "Engenharia de Redes e Serviços", "Tecnologias e Protocolos de Infraestrutura" };
            string[] ano2 = { "Engenharia de Tráfego" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
        }

        private static void populateDisciplinasMIEC()
        {
            string[] ano1 = { "Álgebra Linear e Geometria Analitica A", "Cálculo A", "Ciência dos Materiais de Construção", "Informática A", "Introdução à Engenharia e Técnicas de Representação", "Análise Matemática A", "Desenho e Elementos de Arquitectura", "Física B", "Mecânica das Estruturas", "Métodos Numéricos D" };
            string[] ano2 = { "Complementos de Análise Matemática A", "Electromagnetismo B", "Materiais de Construção I", "Métodos Estatísticos A", "Resistência dos Materiais I", "Geologia de Engenharia Civil", "Investigação Operacional", "Materiais de Construção II", "Organização e Gestão da Construção I", "Resistência dos Materiais II", "Topografia" };
            string[] ano3 = { "Análise de Estruturas I", "Física das Construções", "Hidráulica Geral I", "Organização e Gestão da Construção II", "Vias de Comunicação I", "Análise de Estruturas II", "Geotecnia I", "Hidráulica Geral II", "Planeamento Territorial", "Vias de Comunicação II" };
            string[] ano4 = { "Estruturas de Betão I", "Geotecnia II", "Hidráulica Urbana", "Planeamento Urbano", "Tecnologia das Construções", "Estruturas de Betão II", "Hidrologia Aplicada", "Instalações das Construções" };
            string[] ano5 = { "Construção Sustentável", "Qualidade, Segurança e Ambiente", "Seminário", "Inovação Tecnológica da Construção", "Comportamento Termo-energético de Edifícios", "Complementos de Materiais de Construção I", "Projeto" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
            populateDisciplinasAux(ano4);
            populateDisciplinasAux(ano5);

        }

        private static void populateDisciplinasLDir()
        {
            string[] ano1 = { "Direito Constitucional", "História do Direito", "Introdução ao Estudo do Direito", "Economia Política", "Filosofia Política", "Metodologia do Direito", "Direito Comparado", "Língua Estrangeira: Alemão Jurídico", "Língua Estrangeira: Inglês Jurídico" };
            string[] ano2 = { "Direito Administrativo", "Teoria Geral do Direito Civil", "Direito Internacional Público", "Finanças Públicas", "Direito Comunitário", "Direito Fiscal I", "Criminologia" };
            string[] ano3 = { "Direito das Obrigações", "Direito Penal I", "Direito Processual Civil-Declaratório", "Direito Fiscal II", "Direitos Reais", "Direito Processual Administrativo" };
            string[] ano4 = { "Direito Comercial", "Direito da Família e Sucessões", "Direito do Trabalho", "Direito Penal II", "Direito Processual Civil-Executivo", "Direito Internacional Privado", "Direito Processual Penal", "Direitos Fundamentais" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
            populateDisciplinasAux(ano4);
        }

        private static void populateDisciplinasLCC()
        {
            string[] ano1 = { "Álgebra Linear CC", "Cálculo", "Programação Funcional", "Tópicos de Matemática", "Bioética", "Comunicação, Ciência e Ambiente", "Desenvolvimento Psicológico, Comportamento e Contextos de Vida", "Educação, Cidadania e Direitos Humanos", "Energia e Ambiente", "Escrita Académica", "Gestão do Conhecimento e da Inovação", "Introdução aos Estudos Históricos", "Liderança e Empreendedorismo", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Espanhol", "Língua Estrangeira Nível 1 - Francês", "Língua Estrangeira Nível 1 - Italiano", "Língua Estrangeira Nível 1 - Russo", "Psicologia, Ciências Cognitivas e Comportamento", "Serviços de Informação de Apoio à Comunidade Científica", "Análise", "Geometria", "Laboratório de Algoritmia I", "Matemática Discreta", "Programação Imperativa", "Sistemas de Computação" };
            string[] ano2 = { "Álgebra", "Algoritmos e Complexidade", "Análise Numérica", "Lógica CC", "Sistemas de Comunicações e Redes", "Análise", "Cálculo de Programas", "Geometria", "Laboratório de Algoritmia II", "Programação Orientada aos Objetos", "Sistemas Operativos" };
            string[] ano3 = { "Análise Numérica", "Bases de Dados", "Computabilidade", "Probabilidades e Aplicações", "Programação Concorrente", "Computação Gráfica", "Geometria", "Processos e Concorrência", "Semântica da Programação", "Teoria de Números Computacional" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
        }

        private static void populateDisciplinasMBionfCB()
        {
            string[] ano1 = { "Algoritmos para Análise de Sequências Biológicas", "Biologia de Sistemas", "Biologia Molecular e Celular", "Engenharia Bioquímica", "Laboratórios de Bioinformática", "Métodos Estatísticos para a Bioinformática", "Algoritmos Avançados de Bioinformática", "Engenharia Genética", "Extração de Conhecimento de Bases de Dados Biológicos", "Modelação de Processos Biológicos", "Projeto de Bioinformática e Biologia de Sistemas" };
            string[] ano2 = { "Dissertação em Bioinformática", "Empreeendedorismo em Biotecnologia e Bioinformática", "Métodos de Investigação em Bioinformática", "Sistemas Inteligentes para a Bioinformática" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
        }

        private static void populateDisciplinasMIEBiol()
        {
            string[] ano1 = { "Álgebra Linear EE", "Cálculo EE", "Computação e Programação", "Laboratórios Integrados de Química", "Química Analítica", "Sistemas de Representação Gráfica", "Análise Matemática EE", "Biologia Celular e Molecular", "Física EE", "Introdução à Engenharia de Processo", "Laboratórios Integrados de Física", "Química Orgânica EE" };
            string[] ano2 = { "Complementos de Análise Matemática EE", "Electromagnetismo EE", "Fenómenos de Transferência I", "Física EE", "Laboratórios Integrados de Biologia", "Microbiologia", "Termodinâmica Química", "Bioquímica e Fisiologia Microbianas", "Fenómenos de Transferência II", "Laboratórios de Fenómenos de Transferência", "Métodos Estatísticos EE", "Métodos Numéricos", "Química-Física" };
            string[] ano3 = { "Biologia Molecular Aplicada", "Engenharia da Reação Química I", "Engenharia dos Sistemas Processuais", "Engenharia Enzimática", "Laboratórios de Tecnologia Química", "Processos de Separação I", "Engenharia Bioquímica", "Engenharia da Reação Química II", "Engenharia Económica", "Laboratórios de Bioprocessos", "Processos de Separação II", "Tópicos Complementares" };
            string[] ano4 = { "Elementos de Engenharia do Ambiente", "Elementos de Qualidade e Fiabilidade", "Estratégia em Engenharia de Processo", "Laboratórios de Tecnologia Ambiental", "Tratamento de Água e Efluentes Líquidos", "Controlo e Instrumentação de Processos", "Gestão Ambiental", "Poluição do Ar", "Projeto em Engenharia de Processo", "Tratamento de Resíduos Sólidos" };
            string[] ano5 = { "Projeto Individual em Engenharia Biológica", "Produtos e Processos Limpos", "Tecnologias Ambientais", "Biotecnologia Molecular", "Enologia", "Bioinformática e Biologia de Sistemas", "Energia e Ambiente", "Inovação e Empreendedorismo em Biotecnologia e Bioinformática", "Bioética", "Catástrofes Naturais", "Comunicação, Ciência e Ambiente", "Desenvolvimento Psicológico, Comportamento e Contextos de Vida", "Educação, Cidadania e Direitos Humanos", "Escrita Académica", "Gestão do Conhecimento e da Inovação", "Introdução aos Estudos Históricos", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Espanhol", "Língua Estrangeira Nível 1 - Francês", "Língua Estrangeira Nível 1 - Italiano", "Língua Estrangeira Nível 1 - Russo", "Matemática das Coisas", "Moléculas, Cultura e Sociedade", "Psicologia, Ciências Cognitivas e Comportamento", "Dissertação em Engenharia Biológica" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
            populateDisciplinasAux(ano4);
            populateDisciplinasAux(ano5);
        }

        private static void populateDisciplinasMIEMec()
        {
            string[] ano1 = { "Álgebra Linear EE", "Cálculo EE", "Ciência e Tecnologia dos Materiais", "Desenho e Métodos Gráficos", "Electromagnetismo EE", "Integradora I", "Algoritmia e Programação", "Análise Matemática EE", "Desenho e Modelação Assistidos por Computador", "Integradora II", "Mecânica Geral", "Metalurgia Mecânica" };
            string[] ano2 = { "Complementos de Análise Matemática EE", "Eletrotecnia e Eletrónica", "Estatística Aplicada", "Integradora III", "Mecânica dos Materiais I", "Termodinâmica", "Automação Industrial", "Integradora IV", "Mecânica dos Fluidos", "Mecânica dos Materiais II", "Métodos Numéricos", "Tecnologias de Maquinagem e Conformação" };
            string[] ano3 = { "Especificação e Comando de Sistemas a Eventos Discretos", "Integradora V", "Órgãos de Máquinas I", "Técnicas de CAM/CAE", "Tecnologias de Fundição e Soldadura", "Transferência de Calor", "Energética Industrial", "Integradora VI", "Mecânica Computacional", "Órgãos de Máquinas II", "Teoria do Projeto Mecânico", "Tribologia" };
            string[] ano4 = { "Avaliação Económica de Projetos", "Controlo de Processos", "Integradora VII", "Máquinas Térmicas e Fluidos", "Tratamentos Térmicos", "Conceção de Estruturas", "Energia e Ambiente", "Tecnologias da Manufatura", "Complementos de Física", "Integradora VIII", "Organização e Gestão da Produção" };
            string[] ano5 = { "Dissertação em Engenharia Mecânica", "Análise de Dados com Software Estatístico: SPSS e R", "Catástrofes Naturais", "Educação, Cidadania e Direitos Humanos", "Inglês Académico", "Leitura e Escrita para a Produção de Conhecimento Académico", "Língua Estrangeira Nível 1 - Alemão", "Língua Estrangeira Nível 1 - Francês", "Ótica na Natureza, Fotografia e Cinema 3D", "Gestão da Atividade Industrial" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
            populateDisciplinasAux(ano3);
            populateDisciplinasAux(ano4);
            populateDisciplinasAux(ano5);
        }

        private static void populateDisciplinasMEI()
        {
            string[] ano1 = { "Análise e Conceção de Software", "Bioinformática", "Computação Gráfica", "Computação Paralela Distribuída", "Criptografia e Segurança de Sistemas de Informação", "Engenharia de Aplicações", "Engenharia de Linguagens", "Engenharia de Redes de Computadores", "Engenharia de Serviços de Comunicações e Sistemas Ubíquos", "Métodos Formais em Engenharia de Software", "Sistemas de Suporte à Decisão", "Sistemas Distribuídos", "Sistemas Inteligentes" };
            string[] ano2 = { "Dissertação", "Seminário" };
            populateDisciplinasAux(ano1);
            populateDisciplinasAux(ano2);
        }

        private static void populateAnosLectivos()
        {
            string[] anosLectivos = { "1990-1991", "1991-1992", "1992-1993", "1993-1994", "1994-1995", "1995-1996", "1996-1997", "1997-1998", "1998-1999", "1999-2000", "2000-2001", "2001-2002", "2002-2003", "2003-2004", "2004-2005", "2005-2006", "2006-2007", "2007-2008", "2008-2009", "2009-2010", "2010-2011", "2011-2012", "2012-2013" };

            foreach(string anoLectivo in anosLectivos){
                AnosLectivos.insere(anoLectivo);
            }
        }

        private static void populateAnos()
        {
            string[] siglas = { "DCPRI", "DCCom", "DCE", "DCont", "DEco", "DEC", "DFis", "DGeoEP", "DMarkE", "DMCLAC", "DSoc", "LAP", "LArq", "LBiolG", "LBA", "LBioq", "LCP", "LCC", "LCCom", "LCA", "LCont", "LDP", "LDMM", "LDir", "LEco", "LEdu", "LEduB", "LEnf", "LEI", "LEA", "LEC", "LEPL", "LFil", "LFis", "LGeoP", "LGeol", "LGest", "LHist", "LLA", "LLCO", "LLLE", "LMark", "LMat", "LMus", "LNI", "LOCV", "LQui", "LRI", "LSoc", "LTeatro", "MAP", "MArq", "MBioeng", "MBiofB", "MBionfCB", "MBionfTI", "MBiolMBiotBP", "MBioqABiomed", "MBioqABioq", "MBioqABiot", "MCComAudio", "MCComInf", "MCComPub", "MCEduAE", "MCEduDCI", "MCEduEA", "MCEduES", "MCEduSoc", "MCEduSPEduHist", "MCEduSPEduL", "MCEduSPEduMat", "MCL", "MCTAE", "MCTAM", "MComAC", "MComCE", "MCRSCGSE", "MCRSCRE", "MCont", "MCDD", "MDCM", "MDesMark", "MDirAdm", "MDirUE", "MDirAL", "MDirCE", "MDirInf", "MDirJ", "MDirTF", "MDirH", "MEcol", "MEcon", "MEconIE", "MEconMBF", "MEcoSoc", "MEduAIC", "MEduFTRH", "MEduMESF", "MEduIPIF", "MEduISPI", "MEduE", "MEduPE", "MEduPEEB", "MESist", "MEGestSI", "MEH", "MEInd", "MEI", "MEM", "MEUCS", "MEUHA", "MEUIV", "MEst", "MEC", "MEGest", "MF", "MFisA", "MFisF", "MGMol", "MGeo", "MGestA", "MGestRH", "MGestUS", "MHist", "MMarkEstr", "MMCL", "MMNano", "MNI", "MOA", "MQuiM", "MRSCom", "MRI", "MSerI", "MSisI", "MSocDPS", "MSocOT", "MTCAQ", "MTLLL", "MTComM", "MIArq", "MIEBiol", "MIEBiom", "MIEC", "MIEMat", "MIEGSI", "MIEGI", "MIEMec", "MIPsi", "PDBio", "PDEBiom", "PDETMRCE", "PDEQuiBiol" };
            int[] anos = { 4, 3, 3, 3, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 3, 3, 3, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 3, 3, 3 };
            int numCursos = 152;

            for (int i = 0; i < numCursos; i++)
            {
                for (int j = 0; j < anos[i]; j++)
                {
                    CursosAnos.insere(j+1, siglas[i]);
                }
            }
        }

        private static void populateCursos()
        {
            string[] cursos = { "Doutoramento em Ciência Política e Relações Internacionais", "Doutoramento em Ciências da Comunicação", "Doutoramento em Ciências Empresariais", "Doutoramento em Contabilidade", "Doutoramento em Economia", "Doutoramento em Estudos da Criança", "Doutoramento em Física", "Doutoramento em Geografia - Estudos da Paisagem", "Doutoramento em Marketing e Estratégia", "Doutoramento em Modernidades Comparadas: Literaturas, Artes e culturas", "Doutoramento em Sociologia", "Licenciatura em Administração Pública", "Licenciatura em Arqueologia", "Licenciatura em Biologia - Geologia", "Licenciatura em Biologia Aplicada", "Licenciatura em Bioquímica", "Licenciatura em Ciência Política (Pós-laboral)", "Licenciatura em Ciências da Computação", "Licenciatura em Ciências da Comunicação", "Licenciatura em Ciências do Ambiente (Pós-laboral)", "Licenciatura em Contabilidade (Pós-laboral)", "Licenciatura em Design de Produto", "Licenciatura em Design e Marketing de Moda", "Licenciatura em Direito", "Licenciatura em Economia", "Licenciatura em Educação", "Licenciatura em Educação Básica", "Licenciatura em Enfermagem", "Licenciatura em Engenharia Informática", "Licenciatura em Estatística Aplicada", "Licenciatura em Estudos Culturais (Pós-laboral)", "Licenciatura em Estudos Portugueses e Lusófonos", "Licenciatura em Filosofia", "Licenciatura em Física", "Licenciatura em Geografia e Planeamento", "Licenciatura em Geologia (Pós-laboral)", "Licenciatura em Gestão", "Licenciatura em História", "Licenciatura em Línguas Aplicadas", "Licenciatura em Línguas e Culturas Orientais", "Licenciatura em Línguas e Literaturas Europeias", "Licenciatura em Marketing (Pós-laboral)", "Licenciatura em Matemática", "Licenciatura em Música (Pós-laboral)", "Licenciatura em Negócios Internacionais (Pós-laboral)", "Licenciatura em Optometria e Ciências da Visão", "Licenciatura em Química", "Licenciatura em Relações Internacionais", "Licenciatura em Sociologia", "Licenciatura em Teatro", "Mestrado em Administração Pública - Gestão Pública e Políticas Públicas (Pós-Laboral)", "Mestrado em Arqueologia", "Mestrado em Bioengenharia", "Mestrado em Biofísica e Bionanossistemas", "Mestrado em Bioinformática - Ciências Biológicas", "Mestrado em Bioinformática - Tecnologias de Informação", "Mestrado em Biologia Molecular, Biotecnologia e Bioempreendedorismo em Plan", "Mestrado em Bioquímica Aplicada - Biomedicina", "Mestrado em Bioquímica Aplicada - Bioquímica Molecular e Analítica", "Mestrado em Bioquímica Aplicada - Biotecnologia", "Mestrado em Ciências da Comunicação - Audiovisual e Multimédia (Pós-Laboral)", "Mestrado em Ciências da Comunicação - Informação e Jornalismo (Pós-Laboral)", "Mestrado em Ciências da Comunicação - Publicidade e Relações Públicas (Pós-Laboral)", "Mestrado em Ciências da Educação - Administração Educacional", "Mestrado em Ciências da Educação - Desenvolvimento Curricular e Inovação Educativa", "Mestrado em Ciências da Educação - Educação de Adultos", "Mestrado em Ciências da Educação - Educação para a Saúde (Pós-Laboral)", "Mestrado em Ciências da Educação - Sociologia da Educação e Políticas Educativas (Pós-Laboral)", "Mestrado em Ciências da Educação - Supervisão Pedagógica na Educação em História e Ciências Sociais", "Mestrado em Ciências da Educação - Supervisão Pedagógica na Educação em Línguas", "Mestrado em Ciências da Educação - Supervisão Pedagógica na Educação Matemática", "Mestrado em Ciências da Linguagem", "Mestrado em Ciências e Tecnologias do Ambiente - Energia", "Mestrado em Ciências e Tecnologias do Ambiente - Monitorização e Remediação Ambiental", "Mestrado em Comunicação, Arte e Cultura (Pós-Laboral)", "Mestrado em Comunicação, Cidadania e Educação (Pós-Laboral)", "Mestrado em Construção e Reabilitação Sustentáveis - Concepção e Gestão Sustentável de Edifícios", "Mestrado em Construção e Reabilitação Sustentáveis - Conservação e Reabilitação de Edifícios", "Mestrado em Contabilidade (Pós-Laboral)", "Mestrado em Crime, Diferença e Desigualdade", "Mestrado em Design de Comunicação de Moda", "Mestrado em Design e Marketing", "Mestrado em Direito Administrativo (Pós-Laboral)", "Mestrado em Direito da União Europeia", "Mestrado em Direito das Autarquias Locais (Pós-Laboral)", "Mestrado em Direito dos Contratos e das Empresas (Pós-Laboral)", "Mestrado em Direito e Informática (Pós-Laboral)", "Mestrado em Direito Judiciário (Direitos Processuais e Organização Judiciária) (Pós-Laboral)", "Mestrado em Direito Tributário e Fiscal", "Mestrado em Direitos Humanos", "Mestrado em Ecologia", "Mestrado em Economia", "Mestrado em Economia Industrial e da Empresa", "Mestrado em Economia Monetária, Bancária e Financeira (Pós-Laboral)", "Mestrado em Economia Social (Pós-Laboral)", "Mestrado em Educação - Educação de Adultos e Intervenção Comunitária", "Mestrado em Educação - Formação, Trabalho e Recursos Humanos", "Mestrado em Educação - Mediação Educacional e Supervisão na Formação", "Mestrado em Educação da Infância - Pedagogia Intercultural na Infância", "Mestrado em Educação da Infância - Supervisão e Pedagogia da Infância", "Mestrado em Educação Especial - Intervençao Precoce (Pós-Laboral)", "Mestrado em Educação Pré-Escolar", "Mestrado em Educação Pré-Escolar e Ensino do 1º Ciclo do Ensino Básico", "Mestrado em Engenharia de Sistemas", "Mestrado em Engenharia e Gestão de Sistemas de Informação", "Mestrado em Engenharia Humana (Pós-Laboral)", "Mestrado em Engenharia Industrial - Avaliação e Gestão de Projectos e da Inovação", "Mestrado em Engenharia Informática", "Mestrado em Engenharia Mecatrónica (Pós-Laboral)", "Mestrado em Engenharia Urbana - Cidades Sustentáveis", "Mestrado em Engenharia Urbana - Hidráulica Ambiental", "Mestrado em Engenharia Urbana - Infra-Estruturas Viárias", "Mestrado em Estatística", "Mestrado em Estudos da Criança - Intervenção Psicossocial com Crianças, Jovens e Famílias", "Mestrado em Estudos de Gestão (Pós-Laboral)", "Mestrado em Finanças", "Mestrado em Física - Física Aplicada", "Mestrado em Física - Física Fundamental", "Mestrado em Genética Molecular", "Mestrado em Geografia - Planeamento e Gestão do Território", "Mestrado em Gestão Ambiental", "Mestrado em Gestão de Recursos Humanos (Pós-Laboral)", "Mestrado em Gestão de Unidades de Saúde (Pós-Laboral)", "Mestrado em História", "Mestrado em Marketing e Estratégia", "Mestrado em Mediação Cultural e Literária", "Mestrado em Micro/Nanotecnologias", "Mestrado em Negócios Internacionais (Pós-Laboral)", "Mestrado em Optometria Avançada", "Mestrado em Química Medicinal", "Mestrado em Redes e Serviços de Comunicações", "Mestrado em Relações Internacionais (Pós-Laboral)", "Mestrado em Serviços de Informação", "Mestrado em Sistemas de Informação", "Mestrado em Sociologia - Desenvolvimento e Políticas Sociais (Pós-Laboral)", "Mestrado em Sociologia - Organizações e Trabalho (Pós-Laboral)", "Mestrado em Técnicas de Caracterização e Análise Química", "Mestrado em Teoria da Literatura e Literaturas Lusófonas", "Mestrado em Tradução e Comunicação Multilingue", "Mestrado Integrado em Arquitetura", "Mestrado Integrado em Engenharia Biológica", "Mestrado Integrado em Engenharia Biomédica", "Mestrado Integrado em Engenharia Civil", "Mestrado Integrado em Engenharia de Materiais", "Mestrado Integrado em Engenharia e Gestão de Sistemas de Informação", "Mestrado Integrado em Engenharia e Gestão Industrial", "Mestrado Integrado em Engenharia Mecânica", "Mestrado Integrado em Psicologia", "Programa Doutoral em Bioengenharia", "Programa Doutoral em Engenharia Biomédica", "Programa Doutoral em Engenharia de Tecidos, Medicina Regenerativa e Células Estaminais", "Programa Doutoral em Engenharia Química e Biológica" };
            string[] siglas = { "DCPRI", "DCCom", "DCE", "DCont", "DEco", "DEC", "DFis", "DGeoEP", "DMarkE", "DMCLAC", "DSoc", "LAP", "LArq", "LBiolG", "LBA", "LBioq", "LCP", "LCC", "LCCom", "LCA", "LCont", "LDP", "LDMM", "LDir", "LEco", "LEdu", "LEduB", "LEnf", "LEI", "LEA", "LEC", "LEPL", "LFil", "LFis", "LGeoP", "LGeol", "LGest", "LHist", "LLA", "LLCO", "LLLE", "LMark", "LMat", "LMus", "LNI", "LOCV", "LQui", "LRI", "LSoc", "LTeatro", "MAP", "MArq", "MBioeng", "MBiofB", "MBionfCB", "MBionfTI", "MBiolMBiotBP", "MBioqABiomed", "MBioqABioq", "MBioqABiot", "MCComAudio", "MCComInf", "MCComPub", "MCEduAE", "MCEduDCI", "MCEduEA", "MCEduES", "MCEduSoc", "MCEduSPEduHist", "MCEduSPEduL", "MCEduSPEduMat", "MCL", "MCTAE", "MCTAM", "MComAC", "MComCE", "MCRSCGSE", "MCRSCRE", "MCont", "MCDD", "MDCM", "MDesMark", "MDirAdm", "MDirUE", "MDirAL", "MDirCE", "MDirInf", "MDirJ", "MDirTF", "MDirH", "MEcol", "MEcon", "MEconIE", "MEconMBF", "MEcoSoc", "MEduAIC", "MEduFTRH", "MEduMESF", "MEduIPIF", "MEduISPI", "MEduE", "MEduPE", "MEduPEEB", "MESist", "MEGestSI", "MEH", "MEInd", "MEI", "MEM", "MEUCS", "MEUHA", "MEUIV", "MEst", "MEC", "MEGest", "MF", "MFisA", "MFisF", "MGMol", "MGeo", "MGestA", "MGestRH", "MGestUS", "MHist", "MMarkEstr", "MMCL", "MMNano", "MNI", "MOA", "MQuiM", "MRSCom", "MRI", "MSerI", "MSisI", "MSocDPS", "MSocOT", "MTCAQ", "MTLLL", "MTComM", "MIArq", "MIEBiol", "MIEBiom", "MIEC", "MIEMat", "MIEGSI", "MIEGI", "MIEMec", "MIPsi", "PDBio", "PDEBiom", "PDETMRCE", "PDEQuiBiol" };
            int numCursos = 152;

            for (int i = 0; i < numCursos; i++)
            {
                DescricoesCurso.insere(siglas[i], cursos[i]);
            }
        }
    }
}