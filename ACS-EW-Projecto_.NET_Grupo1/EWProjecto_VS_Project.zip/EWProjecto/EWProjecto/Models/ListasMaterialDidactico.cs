﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;

namespace EWProjecto.Models
{

    public class ListasMaterialDidactico : ConexaoBD
    {

        public static ListaMaterialDidactico getListaMaterialDidactico(int id)
        {
            //Obter a ListaMaterialDidactico através do oid
            return db.ListaMaterialDidacticos.SingleOrDefault(lmd => lmd.oid == id);
        }

        public static ListaMaterialDidactico getListaMaterialDidactico(string anoLectivo, int oidAnoCurso)
        {
            //Obter a ListaMaterialDidactico através do ano lectivo e do oid curso
            return db.ListaMaterialDidacticos.SingleOrDefault(lmd => lmd.oidAnoLectivo == anoLectivo && lmd.oidCursoAno == oidAnoCurso);
        }

        public static List<ListaMaterialDidactico> getListasMaterialDidacticoAnoLectivo(string anoLectivo)
        {
            //Obter as ListasMaterialDidactico de um certo ano lectivo
            return db.ListaMaterialDidacticos.Where(lmd => lmd.oidAnoLectivo == anoLectivo).OrderBy(lmd => lmd.CursoAno.oidSigla).ToList();
        }

        public static List<ListaMaterialDidactico> getListaMaterialDidacticoCursoAno(int id_cursoAno)
        {
            //Obter as ListasMaterialDidactico de um certo Curso Ano (list porque pode ter vários anos lectivos)
            return db.ListaMaterialDidacticos.Where(lmd => lmd.oidCursoAno == id_cursoAno).ToList();
        }

        public static List<ListaMaterialDidactico> getListasMaterialDidacticoSigla(string siglaCurso)
        {
            //Obter as ListasMaterialDidactico de um certo curso através da sigla
            return db.ListaMaterialDidacticos.Where(lmd => lmd.CursoAno.oidSigla == siglaCurso).ToList();
        }

        public static List<ListaMaterialDidactico> getListasMaterialDidacticoAno(int ano, string siglaCurso)
        {
            //Obter as ListasMaterialDidactico de um certo curso através da sigla e ano
            return db.ListaMaterialDidacticos.Where(lmd => lmd.CursoAno.oidSigla == siglaCurso && lmd.CursoAno.ano == ano).ToList();
        }

        public static List<ListaMaterialDidactico> getAllListasMaterialDidactico()
        {
            //Obter todas as ListasMaterialDidactico
            return db.ListaMaterialDidacticos.ToList();
        }

        public static bool insere(string descricao, string oidAnoLectivo, int oidCursoAno)
        {
            ListaMaterialDidactico lmd = db.ListaMaterialDidacticos.SingleOrDefault(lmd2 => lmd2.oidAnoLectivo == oidAnoLectivo && lmd2.oidCursoAno == oidCursoAno);

            if (lmd != null) return false;

            else
            {
                lmd = new ListaMaterialDidactico();
                lmd.dataActualizacao = DateTime.Now;
                lmd.descricao = descricao;
                lmd.oidAnoLectivo = oidAnoLectivo;
                lmd.oidCursoAno = oidCursoAno;
                db.ListaMaterialDidacticos.InsertOnSubmit(lmd);
                db.SubmitChanges();

                return true;
            }
        }

        public static void remove(int oid)
        {
            ListaMaterialDidactico lmd = db.ListaMaterialDidacticos.SingleOrDefault(lmd2 => lmd2.oid == oid);
            db.ListaMaterialDidacticos.DeleteOnSubmit(lmd);
            db.SubmitChanges();
        }

        public static void actualiza(int oid, string descricao, string oidAnoLectivo, int oidCursoAno)
        {
            //Model_W._data.ListaMaterialDidacticos.Attach(lmd);
            ListaMaterialDidactico lmd = db.ListaMaterialDidacticos.SingleOrDefault(lmd2 => lmd2.oid == oid);
            lmd.dataActualizacao = DateTime.Now;
            lmd.descricao = descricao;
            lmd.AnoLectivo = db.AnoLectivos.Single(al => al.Ano == oidAnoLectivo);
            lmd.CursoAno = db.CursoAnos.Single(ca => ca.oid == oidCursoAno);
            db.Refresh(RefreshMode.KeepCurrentValues, lmd);
            db.SubmitChanges();
        }

        public static void actualizaTime(int oid)
        {
            //Model_W._data.ListaMaterialDidacticos.Attach(lmd);
            ListaMaterialDidactico lmd = db.ListaMaterialDidacticos.SingleOrDefault(lmd2 => lmd2.oid == oid);
            lmd.dataActualizacao = DateTime.Now;
            db.Refresh(RefreshMode.KeepCurrentValues, lmd);
            db.SubmitChanges();
        }
    }
}