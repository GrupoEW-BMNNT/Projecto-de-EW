﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedAdmins : PaginatedList<Utilizador>
    {
        
        public PaginatedAdmins()
            : base(new List<Utilizador>(), 0, 10)
        {
        }

        public PaginatedAdmins(IList<Utilizador> administradores, int pageIndex)
            : base(administradores, pageIndex, 10)
        {
        }
    }
}