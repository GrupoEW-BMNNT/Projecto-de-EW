﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedCursos : PaginatedList<DescricaoCurso>
    {
        public PaginatedCursos()
            : base(new List<DescricaoCurso>(), 0, 10)
        {
        }

        public PaginatedCursos(IList<DescricaoCurso> cursos, int pageIndex)
            : base(cursos, pageIndex, 10)
        {
        }
    }
}