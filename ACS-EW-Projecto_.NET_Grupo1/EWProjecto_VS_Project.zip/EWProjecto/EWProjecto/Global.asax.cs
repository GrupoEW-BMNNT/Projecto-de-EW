﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace EWProjecto
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "PesquisaDisciplinaPage",                               // Route name
                "Pesquisa/Disciplina/Page/{page}",                           // URL with params
                new { controller = "Pesquisa", action = "Disciplina" } // Param defaults
            );

            routes.MapRoute(
                "PesquisaCursoPage",                               // Route name
                "Pesquisa/Curso/Page/{page}",                           // URL with params
                new { controller = "Pesquisa", action = "Curso" } // Param defaults
            );

            routes.MapRoute(
                "PedidosAdminPage",                               // Route name
                "Pedidos/Administrar/Page/{page}",                           // URL with params
                new { controller = "Pedidos", action = "Administrar" } // Param defaults
            );

            routes.MapRoute(
                "PedidosPage",                               // Route name
                "Pedidos/Page/{page}",                           // URL with params
                new { controller = "Pedidos", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "MateriaisPage",                               // Route name
                "ListasMaterial/Detalhes/Page/{page}",                           // URL with params
                new { controller = "ListasMaterial", action = "Editar" } // Param defaults
            );

            routes.MapRoute(
                "ListaListasPage",                               // Route name
                "ListasMaterial/Page/{page}",                           // URL with params
                new { controller = "ListasMaterial", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "EstudantePage",                               // Route name
                "Estudantes/Page/{page}",                           // URL with params
                new { controller = "Estudantes", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "DisciplinaPage",                               // Route name
                "Disciplinas/Page/{page}",                           // URL with params
                new { controller = "Disciplinas", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "CursoPage",                               // Route name
                "Cursos/Page/{page}",                           // URL with params
                new { controller = "Cursos", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "AnoLectivoPage",                               // Route name
                "AnosLectivos/Page/{page}",                           // URL with params
                new { controller = "AnosLectivos", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "AdminPage",                               // Route name
                "Administradores/Page/{page}",                           // URL with params
                new { controller = "Administradores", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "HomeNormal",                               // Route name
                "Home/Page/{page}",                           // URL with params
                new
                { controller = "Home", action = "Index" } // Param defaults
            );

            routes.MapRoute(
                "HomeEstudante",                               // Route name
                "Home/Estudante/Page/{page}",                           // URL with params
                new { controller = "Home", action = "Estudante" } // Param defaults
            );

            routes.MapRoute(
                "Pedidos", // Route name
                "Pedidos/Delete/{oid}", // URL with parameters
                new { controller = "Pedidos", action = "Delete" } // Parameter defaults
            );

            routes.MapRoute(
                "Cursos", // Route name
                "Cursos/Editar/{sigla}", // URL with parameters
                new { controller = "Cursos", action = "Editar" }, // Parameter defaults
                new { sigla = @"\w+" }
            );

            routes.MapRoute(
                "AnosCurso", // Route name
                "AnosCurso/Delete/{oid}", // URL with parameters
                new { controller = "AnosCurso", action = "Delete" } // Parameter defaults
            );

            routes.MapRoute(
                "ListasMaterialEdit", // Route name
                "ListasMaterial/Editar/{oid}", // URL with parameters
                new { controller = "ListasMaterial", action = "Editar" } // Parameter defaults
            );

            routes.MapRoute(
                "ListasMaterialDelete", // Route name
                "ListasMaterial/Delete/{oid}", // URL with parameters
                new { controller = "ListasMaterial", action = "Delete" } // Parameter defaults
            );

            routes.MapRoute(
                "Material", // Route name
                "Material/Delete/{oid}", // URL with parameters
                new { controller = "Material", action = "Delete" } // Parameter defaults
            );

            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Home", action = "Index", id = UrlParameter.Optional } // Parameter defaults
            );


        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);
        }
    }
}