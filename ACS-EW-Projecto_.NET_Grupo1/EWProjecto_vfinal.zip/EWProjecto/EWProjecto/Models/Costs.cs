﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;

namespace EWProjecto.Models
{
    public class Costs : ConexaoBD
    {

        public static Custo getCusto(string descricao)
        {
            //Obter os custos atraves da descricao
            return db.Custos.SingleOrDefault(c => c.descricao == descricao);
        }

        public static List<Custo> getAllCustos()
        {
            //Obter todos os anos lectivos
            return db.Custos.ToList();
        }

        public static bool insere(string descricao, double custo)
        {
            Custo c = db.Custos.SingleOrDefault(c2 => c2.descricao == descricao);
            if (c != null) { return false; }
            
            c = new Custo();
            c.descricao = descricao;
            c.custo1 = custo;
            db.Custos.InsertOnSubmit(c);
            db.SubmitChanges();

            return true;
        }

        public static void remove(int oid)
        {
            Custo c = db.Custos.SingleOrDefault(c2 => c2.oid == oid);
            db.Custos.DeleteOnSubmit(c);
            db.SubmitChanges();
        }

        public static void actualiza(int oid, string descricao, double custo)
        {
            //Model_W._data.CursoAnos.Attach(ca);
            Custo c = db.Custos.SingleOrDefault(c2 => c2.oid == oid);
            c.descricao = descricao;
            c.custo1 = custo;
            db.Refresh(RefreshMode.KeepCurrentValues, c);
            db.SubmitChanges();
        }
    }
}