﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace EWProjecto.Models.Seguranca
{
    public class CCUMRoleProvider : RoleProvider
    {
        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            using (CCUM_ClassesDataContext db = new CCUM_ClassesDataContext())
            {
                foreach (string role in roleNames)
                {
                    foreach (string username in usernames)
                    {
                        Utilizador user = db.Utilizadors.FirstOrDefault(u => u.username == username);
                        Grupo grupo = db.Grupos.FirstOrDefault(gr => gr.nome == role);

                        GruposUtilizador user2Grupo = new GruposUtilizador();
                        user2Grupo.oidGrupo = grupo.oid;
                        user2Grupo.oidUtilizador = user.oid;
                        db.GruposUtilizadors.InsertOnSubmit(user2Grupo);
                        db.SubmitChanges();
                    }
                }
            }
        }

        public override string ApplicationName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override void CreateRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            throw new NotImplementedException();
        }

        public override string[] GetRolesForUser(string username)
        {
            using (CCUM_ClassesDataContext db = new CCUM_ClassesDataContext())
            {
                Utilizador user = db.Utilizadors.FirstOrDefault(u => u.username == username);
                if (user == null) return new string[] { }; ;
                var roles = from userGroups in user.GruposUtilizadors
                            from grupo in db.Grupos
                            where userGroups.oidGrupo == grupo.oid
                            select grupo.nome;
                if (roles != null)
                    return roles.ToArray();
                else
                    return new string[] { }; ;
            }
        }

        public override string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            return this.GetRolesForUser(username).Contains(roleName);
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override bool RoleExists(string roleName)
        {
            throw new NotImplementedException();
        }
    }
}