﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;

namespace EWProjecto.Models
{
    public class Groups : ConexaoBD
    {
        public static void insere(string nome)
        {
            Grupo g = db.Grupos.SingleOrDefault(gr => gr.nome == nome);

            if (g == null)
            {
                g = new Grupo();
                g.nome = nome;
                db.Grupos.InsertOnSubmit(g);
                db.SubmitChanges();
            }
        }
    }
}