﻿using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Web.Mvc;
using System.Collections.Generic;
using EWProjecto.Models.PaginatedClasses;

namespace EWProjecto.Models.ModelViews
{
    public class PedidosModel
    {
        public PaginatedPedidos listaPedidosImpressao { get; set; }
        [Display(Name = "Tipo de pedido de impressão")]
        public int pedidoTipo { get; set; }

        [Display(Name = "Tipo de pedido de impressão")]
        public IEnumerable<SelectListItem> pedidoListaTipos
        {
            get
            {
                return new[]
            {
                new SelectListItem { Value = "0", Text = "Todos" },
                new SelectListItem { Value = "1", Text = "Pendentes" },
                new SelectListItem { Value = "2", Text = "Concluidos" },
                new SelectListItem { Value = "3", Text = "Rejeitados" },
            };
            }
        }

        public PedidosModel()
        {
            this.listaPedidosImpressao = new PaginatedPedidos();
        }

        public PedidosModel(IList<PedidoImpressao> listaPedidosImpressao, int pageIndex)
        {
            this.listaPedidosImpressao = new PaginatedPedidos(listaPedidosImpressao, pageIndex);
        }

        public void setMateriaisAndPage(IList<PedidoImpressao> listaPedidosImpressao, int pageIndex)
        {
            this.listaPedidosImpressao = new PaginatedPedidos(listaPedidosImpressao, pageIndex);
        }
    }
}