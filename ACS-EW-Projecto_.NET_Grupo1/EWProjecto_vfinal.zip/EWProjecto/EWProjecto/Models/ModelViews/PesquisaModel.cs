﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.Web.Mvc;
using EWProjecto.Models.PaginatedClasses;
using System.ComponentModel.DataAnnotations;

namespace EWProjecto.Models.ModelViews
{
    public class PesquisaModel
    {
        [DisplayName("Curso")]
        public string curso { get; set; }
        public int oidDisciplina { get; set; }
        [DisplayName("Disciplina")]
        public string nomeDisciplina { get; set; }
        public PaginatedListasMaterial listaMateriais { get; set; }
        public PaginatedMateriais materiais { get; set; }

        public int oid { get; set; }
        [Required(ErrorMessage = "Tem de especificar o n.º de cópias")]
        [Display(Name = "N.º de cópias")]
        public int pedidoNrCopias { get; set; }
        [Display(Name = "Cor")]
        public bool pedidoCor { get; set; }

        [Required(ErrorMessage = "Tem de escolher uma cor")]
        [Display(Name = "Cor")]
        public IEnumerable<SelectListItem> pedidoListaCores
        {
            get
            {
                return new[]
            {
                new SelectListItem { Value = bool.TrueString, Text = "Cor" },
                new SelectListItem { Value = bool.FalseString, Text = "Preto e branco" },
            };
            }
        }
        [Display(Name = "Frente/Verso")]
        public bool pedidoFrenteVerso { get; set; }

        [Required(ErrorMessage = "Tem de escolher um modo")]
        [Display(Name = "Frente/Verso")]
        public IEnumerable<SelectListItem> pedidoListaFrenteVerso
        {
            get
            {
                return new[]
            {
                new SelectListItem { Value = bool.TrueString, Text = "Sim" },
                new SelectListItem { Value = bool.FalseString, Text = "Não" },
            };
            }
        }

        [Display(Name = "Páginas por folha")]
        public int pedidoPaginasFolha { get; set; }

        [Required(ErrorMessage = "Tem de escolher o número de páginas por folha")]
        [Display(Name = "Páginas por folha")]
        public IEnumerable<SelectListItem> pedidoListaPaginasFolha
        {
            get
            {
                return new[]
            {
                new SelectListItem { Value = "1", Text = "1" },
                new SelectListItem { Value = "2", Text = "2" },
                new SelectListItem { Value = "4", Text = "4" },
                new SelectListItem { Value = "8", Text = "8" },
            };
            }
        }

        public PesquisaModel()
        {
            this.pedidoNrCopias = 1;
            this.pedidoPaginasFolha = 1;
            this.materiais = new PaginatedMateriais();
            this.listaMateriais = new PaginatedListasMaterial();
        }

        public PesquisaModel(IList<ListaMaterialDidactico> listasMaterial, int pageIndex)
        {
            this.listaMateriais = new PaginatedListasMaterial(listasMaterial, pageIndex);
            this.materiais = new PaginatedMateriais();
        }

        public PesquisaModel(IList<MaterialDidactico> materiais, int pageIndex)
        {
            this.pedidoNrCopias = 1;
            this.pedidoPaginasFolha = 1;
            this.listaMateriais = new PaginatedListasMaterial();
            this.materiais = new PaginatedMateriais(materiais, pageIndex);
        }

        public void setListasAndPage(IList<ListaMaterialDidactico> listasMaterial, int pageIndex)
        {
            this.listaMateriais = new PaginatedListasMaterial(listasMaterial, pageIndex);
        }

        public void setMateriaisAndPage(IList<MaterialDidactico> materiais, int pageIndex)
        {
            this.materiais = new PaginatedMateriais(materiais, pageIndex);
        }
    }
}