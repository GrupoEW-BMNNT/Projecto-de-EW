﻿using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Web.Mvc;
using System.Collections.Generic;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;
using EWProjecto.Models.PaginatedClasses;

namespace EWProjecto.Models.ModelViews
{
    //public class ListasMaterialModel
    public class ListasMaterialModel
    {
        [Required(ErrorMessage = "A descricao nao pode ser vazia")]
        [DisplayName("Descricao")]
        [DataType(DataType.Text)]
        public string descricao { get; set; }
        [Required(ErrorMessage = "O curso nao pode ser vazio")]
        [DisplayName("Curso")]
        public string curso { get; set; }
        [DisplayName("Ano")]
        public int oidCurso { get; set; }
        public SelectList anosCurso { get; set; }
        public string anoLectivo { get; set; }
        public SelectList anosLectivos { get; set; }
        public PaginatedListasMaterial listasMaterial { get; set; }

        public ListasMaterialModel()
        {
            anosCurso = new SelectList(Enumerable.Empty<CursoAno>(), "oid", "ano");
            anosLectivos = new SelectList(Enumerable.Empty<AnoLectivo>(), "Ano", "Ano");
            this.listasMaterial = new PaginatedListasMaterial();
        }

        public ListasMaterialModel(IList<ListaMaterialDidactico> listasMaterial, int pageIndex)
        {
            this.listasMaterial = new PaginatedListasMaterial(listasMaterial, pageIndex);
            anosCurso = new SelectList(Enumerable.Empty<CursoAno>(), "oid", "ano");
            anosLectivos = new SelectList(Enumerable.Empty<AnoLectivo>(), "Ano", "Ano");
        }

        public void setListasAndPage(IList<ListaMaterialDidactico> listasMaterial, int pageIndex)
        {
            this.listasMaterial = new PaginatedListasMaterial(listasMaterial, pageIndex);
        }

    }
}