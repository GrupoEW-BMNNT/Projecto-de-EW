﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;

namespace EWProjecto.Models
{
    public class DescricoesCurso : ConexaoBD
    {

        public static DescricaoCurso getCurso(string sigla)
        {
            //Obter os custos atraves da descricao
            return db.DescricaoCursos.SingleOrDefault(dc => dc.sigla == sigla);
        }

        public static List<DescricaoCurso> getAllCursos()
        {
            //Obter todos os cursos
            return db.DescricaoCursos.ToList();
        }

        public static List<DescricaoCurso> getAllCursosByTermo(string termo, int limitSize)
        {
            //Obter todos os anos lectivos com o termo no nome limitado a alguns elementos
            return db.DescricaoCursos.Where(dc => dc.descricao.Contains(termo)).Take(limitSize).ToList();
        }

        public static bool insere(string sigla, string descricao)
        {
            DescricaoCurso dc = db.DescricaoCursos.SingleOrDefault(dc2 => dc2.sigla == sigla);
            if (dc != null) return false;

            dc = new DescricaoCurso();
            dc.sigla = sigla;
            dc.descricao = descricao;
            db.DescricaoCursos.InsertOnSubmit(dc);
            db.SubmitChanges();

            return true;
        }

        public static void remove(string sigla)
        {
            DescricaoCurso dc = db.DescricaoCursos.SingleOrDefault(dc2 => dc2.sigla == sigla);
            db.DescricaoCursos.DeleteOnSubmit(dc);
            db.SubmitChanges();
        }

        public static void actualiza(string sigla, string descricao)
        {
            //Model_W._data.CursoAnos.Attach(ca);
            DescricaoCurso dc = db.DescricaoCursos.SingleOrDefault(dc2 => dc2.sigla == sigla);
            dc.sigla = sigla;
            dc.descricao = descricao;
            db.Refresh(RefreshMode.KeepCurrentValues, dc);
            db.SubmitChanges();
        }
    }
}