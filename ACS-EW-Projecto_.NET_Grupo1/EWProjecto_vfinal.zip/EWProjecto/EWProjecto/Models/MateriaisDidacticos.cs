﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Linq;

namespace EWProjecto.Models
{
    public class MateriaisDidacticos : ConexaoBD
    {

        public static List<MaterialDidactico> getMaterialDidaticoListaMaterial(int id_lista)
        {
            //ir buscar o material didático de uma lista de material
            return db.MaterialDidacticos.Where(md => md.oidLista == id_lista).ToList();
        }

        public static List<MaterialDidactico> getMaterialDidaticoCursoAno(int id_cursoAno)
        {
            //obter material didatico de um CursoANo
            List<MaterialDidactico> toReturn = new List<MaterialDidactico>();
            List<ListaMaterialDidactico> listas = db.ListaMaterialDidacticos.Where(lmd => lmd.oidCursoAno == id_cursoAno).ToList();
            foreach (ListaMaterialDidactico l in listas){
                int oidLista = l.oid;
                List<MaterialDidactico> temp = db.MaterialDidacticos.Where(md => md.oidLista == oidLista).ToList(); 
                toReturn = toReturn.Union(temp).ToList();
            }
            return toReturn; 
        }

        public static List<MaterialDidactico> getMaterialDidaticoDisciplina(int disciplina)
        {
            //obter material didatico de uma disciplina
            return db.MaterialDidacticos.Where(md => md.oidDisciplina == disciplina).ToList(); 
        }

        public static List<MaterialDidactico> getAllMaterialDidatico()
        {
            //obter todos os materiais didaticos
            return db.MaterialDidacticos.ToList();
        }

        public static MaterialDidactico getMaterialDidactico(int id)
        {
            //obter material didatico por id
            return db.MaterialDidacticos.SingleOrDefault(md => md.oid == id);
        }

        public static MaterialDidactico getMaterialDidactico(string nome)
        {
            //obter material didatico por nome
            return db.MaterialDidacticos.SingleOrDefault(md => md.nome == nome);
        }

        public static void insere(string descricao, string nome, int nrPaginas, int oidDisciplina, int oidLista)
        {
            MaterialDidactico md = new MaterialDidactico();
            md.descricao = descricao;
            md.nome = nome;
            md.nrPaginas = nrPaginas;
            md.oidDisciplina = oidDisciplina;
            md.oidLista = oidLista;
            db.MaterialDidacticos.InsertOnSubmit(md);
            db.SubmitChanges();
        }

        public static void remove(int oid)
        {
            MaterialDidactico md = db.MaterialDidacticos.SingleOrDefault(md2 => md2.oid == oid);
            db.MaterialDidacticos.DeleteOnSubmit(md);
            db.SubmitChanges();
        }

        public static void actualiza(int oid, string descricao, string nome, int nrPaginas, int oidDisciplina, int oidLista)
        {
            //Model_W._data.Clientes.Attach(c);
            MaterialDidactico md = db.MaterialDidacticos.SingleOrDefault(md2 => md2.oid == oid);
            md.descricao = descricao;
            md.nome = nome;
            md.nrPaginas = nrPaginas;
            md.Disciplina = db.Disciplinas.Single(d => d.oid == oidDisciplina);
            md.ListaMaterialDidactico = db.ListaMaterialDidacticos.Single(lm => lm.oid == oidLista);
            db.Refresh(RefreshMode.KeepCurrentValues, md);
            db.SubmitChanges();
        }
    }
}