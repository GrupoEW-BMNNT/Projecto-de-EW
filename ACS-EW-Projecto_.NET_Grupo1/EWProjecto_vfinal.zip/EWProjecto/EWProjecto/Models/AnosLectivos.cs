﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;

namespace EWProjecto.Models
{

    public class AnosLectivos : ConexaoBD
    {

        public static AnoLectivo getAnoLectivo(string ano)
        {
            //Obter o ano lectivo por ano
            AnoLectivo cl = db.AnoLectivos.FirstOrDefault(r => r.Ano == ano);
            return cl;
        }

        public static List<AnoLectivo> getAllAnoLectivo()
        {
            //Obter todos os anos lectivos
            return db.AnoLectivos.OrderByDescending(al => al.Ano).ToList();
        }

        public static bool insere(String anoLectivo)
        {
            AnoLectivo al = db.AnoLectivos.SingleOrDefault(al2 => al2.Ano == anoLectivo);
            if (al != null) return false;

            al = new AnoLectivo();
            al.Ano = anoLectivo;
            db.AnoLectivos.InsertOnSubmit(al);
            db.SubmitChanges();

            return true;
        }

        public static void remove(String anoLectivo)
        {
            AnoLectivo al = db.AnoLectivos.SingleOrDefault(al2 => al2.Ano == anoLectivo);
            if (al != null)
            {
                db.AnoLectivos.DeleteOnSubmit(al);
                db.SubmitChanges();
            }
        }

        public static void actualiza(String anoLectivo)
        {
            //Model_W._data.AnoLectivos.Attach(al);
            AnoLectivo al = db.AnoLectivos.SingleOrDefault(al2 => al2.Ano == anoLectivo);
            al.Ano = anoLectivo;
            db.Refresh(RefreshMode.KeepCurrentValues, al);
            db.SubmitChanges();
        }
    }
}