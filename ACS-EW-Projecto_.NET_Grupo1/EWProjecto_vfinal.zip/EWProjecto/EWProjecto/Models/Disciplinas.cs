﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Linq;

namespace EWProjecto.Models
{
    public class Disciplinas : ConexaoBD
    {

        public static List<Disciplina> getAllDisciplinas()
        {
            //obter todas as disciplinas
            return db.Disciplinas.ToList();
        }

        public static List<Disciplina> getAllDisciplinasByTermo(string termo, int limitSize)
        {
            //Obter todas as disciplinas com o termo no nome limitado a alguns elementos
            return db.Disciplinas.Where(d => d.nome.Contains(termo)).Take(limitSize).ToList();
        }

        public static Disciplina getDisciplina(int oid)
        {
            //obter disciplina por oid
            return db.Disciplinas.FirstOrDefault(d => d.oid == oid);
        }

        public static Disciplina getDisciplina(string nome)
        {
            //obter disciplina por nome
            return db.Disciplinas.FirstOrDefault(d => d.nome == nome);
        }

        public static bool insere(string nome)
        {
            Disciplina d = db.Disciplinas.SingleOrDefault(d2 => d2.nome == nome);

            if (d != null) return false;
            else
            {
                d = new Disciplina();
                d.nome = nome;
                db.Disciplinas.InsertOnSubmit(d);
                db.SubmitChanges();

                return true;
            }
        }

        public static void remove(int oid)
        {
            Disciplina d = db.Disciplinas.SingleOrDefault(d2 => d2.oid == oid);
            db.Disciplinas.DeleteOnSubmit(d);
            db.SubmitChanges();
        }

        public static void actualiza(int oid, string nome)
        {
            //Model_W._data.Clientes.Attach(c);
            Disciplina d = db.Disciplinas.SingleOrDefault(d2 => d2.oid == oid);
            d.nome = nome;
            db.Refresh(RefreshMode.KeepCurrentValues, d);
            db.SubmitChanges();
        }

    }
}