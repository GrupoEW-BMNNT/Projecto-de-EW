﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedListasMaterial : PaginatedList<ListaMaterialDidactico>
    {
        
        public PaginatedListasMaterial()
        : base(new List<ListaMaterialDidactico>(), 0, 10)
        {
        }

        public PaginatedListasMaterial(IList<ListaMaterialDidactico> listasMaterial, int pageIndex)
            : base(listasMaterial, pageIndex, 10)
        {
        }
    }
}