﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedMateriais : PaginatedList<MaterialDidactico>
    {
        
        public PaginatedMateriais()
            : base(new List<MaterialDidactico>(), 0, 10)
        {
        }

        public PaginatedMateriais(IList<MaterialDidactico> materiais, int pageIndex)
            : base(materiais, pageIndex, 10)
        {
        }
    }
}