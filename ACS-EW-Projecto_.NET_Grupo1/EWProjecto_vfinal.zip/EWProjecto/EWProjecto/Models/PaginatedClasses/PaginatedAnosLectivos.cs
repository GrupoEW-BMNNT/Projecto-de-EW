﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedAnosLectivos : PaginatedList<AnoLectivo>
    {
        public PaginatedAnosLectivos()
        : base(new List<AnoLectivo>(), 0, 10)
        {
        }

        public PaginatedAnosLectivos(IList<AnoLectivo> anosLectivos, int pageIndex)
            : base(anosLectivos, pageIndex, 10)
        {
        }
    }
}