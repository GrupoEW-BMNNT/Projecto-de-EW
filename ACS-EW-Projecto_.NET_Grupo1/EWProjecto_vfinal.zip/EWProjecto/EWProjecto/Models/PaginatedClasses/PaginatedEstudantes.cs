﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedEstudantes : PaginatedList<Estudante>
    {
        public PaginatedEstudantes()
            : base(new List<Estudante>(), 0, 10)
        {
        }

        public PaginatedEstudantes(IList<Estudante> estudantes, int pageIndex)
            : base(estudantes, pageIndex, 10)
        {
        }
    }
}