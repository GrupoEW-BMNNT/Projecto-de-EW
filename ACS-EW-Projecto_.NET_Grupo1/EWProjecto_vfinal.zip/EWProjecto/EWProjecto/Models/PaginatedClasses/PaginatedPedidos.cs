﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedPedidos : PaginatedList<PedidoImpressao>
    {
        public PaginatedPedidos()
            : base(new List<PedidoImpressao>(), 0, 10)
        {
        }

        public PaginatedPedidos(IList<PedidoImpressao> pedidos, int pageIndex)
            : base(pedidos, pageIndex, 10)
        {
        }
    }
}