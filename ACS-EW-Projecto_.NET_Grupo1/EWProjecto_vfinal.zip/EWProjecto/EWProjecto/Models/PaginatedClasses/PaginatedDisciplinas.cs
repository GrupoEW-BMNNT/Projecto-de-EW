﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EWProjecto.Models.MVCUtils;
using EWProjecto.Models;

namespace EWProjecto.Models.PaginatedClasses
{
    public class PaginatedDisciplinas : PaginatedList<Disciplina>
    {
        public PaginatedDisciplinas()
            : base(new List<Disciplina>(), 0, 10)
        {
        }

        public PaginatedDisciplinas(IList<Disciplina> disciplinas, int pageIndex)
            : base(disciplinas, pageIndex, 10)
        {
        }
    }
}