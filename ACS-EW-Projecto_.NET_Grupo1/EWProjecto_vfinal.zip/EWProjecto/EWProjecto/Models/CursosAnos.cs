﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Linq;

namespace EWProjecto.Models
{

    public class CursosAnos : ConexaoBD
    {

        public static List<CursoAno> getCursoAno(int ano, string sigl)
        {
            //Obter os cursoAnos através do ano e da sigla
            return db.CursoAnos.Where(c => c.DescricaoCurso.sigla == sigl && c.ano == ano).ToList();
        }

        public static CursoAno getCursoAno(int id)
        {
            //Obter o cursoAno através do oid
            return db.CursoAnos.SingleOrDefault(c => c.oid == id);
        }

        public static CursoAno getCursoAnoByAnoSigla(int ano, string sigla)
        {
            //Obter o cursoAno através do oid
            return db.CursoAnos.SingleOrDefault(c => c.oidSigla == sigla && c.ano == ano);
        }

        public static List<CursoAno> getCursoAno(string sigl)
        {
            //Obter os cursoAnos através da sigla
            return db.CursoAnos.Where(c => c.DescricaoCurso.sigla == sigl).OrderBy(c => c.ano).ToList();
        }

        public static List<CursoAno> getAllCursoAno()
        {
            //Obter todos os anos de curso
            return db.CursoAnos.ToList();
        }

        public static bool insere(int ano, string sigl)
        {
            CursoAno ca = db.CursoAnos.SingleOrDefault(ca2 => ca2.oidSigla == sigl && ca2.ano == ano);
            if (ca != null) return false;

            ca = new CursoAno();
            ca.ano = ano;
            ca.oidSigla = sigl;
            db.CursoAnos.InsertOnSubmit(ca);
            db.SubmitChanges();

            return true;
        }

        public static void remove(int oid)
        {
            CursoAno ca = db.CursoAnos.SingleOrDefault(ca2 => ca2.oid == oid);
            if (ca != null)
            {
                db.CursoAnos.DeleteOnSubmit(ca);
                db.SubmitChanges();
            }
        }

        public static void actualiza(int oid, int ano, string sigl)
        {
            //Model_W._data.CursoAnos.Attach(ca);
            CursoAno ca = db.CursoAnos.SingleOrDefault(ca2 => ca2.oid == oid);
            ca.ano = ano;
            ca.DescricaoCurso = db.DescricaoCursos.Single(dc => dc.sigla == sigl);
            db.Refresh(RefreshMode.KeepCurrentValues, ca);
            db.SubmitChanges();
        }

    }
}