﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using EWProjecto.Models.ModelViews;
using EWProjecto.Models;
using System.Security.Cryptography;

namespace EWProjecto.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                string[] rolesArray = Roles.GetRolesForUser(model.username);

                bool isEstudante = false;

                foreach (string role in rolesArray)
                    if (role.Equals("Estudante")) 
                        isEstudante = true;

                Utilizador utilizador = Utilizadores.getUtilizador(model.username);

                if (utilizador != null)
                {
                    string password = Estudantes.ComputeHash(model.password, new SHA512CryptoServiceProvider());
                    if (utilizador.password.Equals(password))
                    {
                        FormsAuthentication.SetAuthCookie(model.username, false);

                        if (isEstudante)
                            return RedirectToAction("Estudante", "Home");
                        else
                            return RedirectToAction("Index", "Home");
                    }
                    else {
                        ModelState.AddModelError("", "Password errada");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Utilizador não existente");
                }
            }

            return View(model);
        }
    }
}
