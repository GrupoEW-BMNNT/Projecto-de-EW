﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;
using System.Web.Security;

namespace EWProjecto.Controllers
{
    public class RegistoController : Controller
    {
        //
        // GET: /Registo/

        public ActionResult Index()
        {
            RegistoModel model = new RegistoModel();
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(RegistoModel model)
        {
            if (ModelState.IsValid)
            {
                DescricaoCurso dc = DescricoesCurso.getCurso(model.curso);
                if (dc != null)
                {
                    bool inserted = Estudantes.insere(model.contacto, model.email, model.oidCurso, model.password, model.username);
                    if (inserted)
                    {
                        if (!Roles.IsUserInRole(model.username, "Estudante"))
                        {
                            Roles.AddUserToRole(model.username, "Estudante");
                        }

                        ViewBag.username = User.Identity.Name;
                        return RedirectToAction("Index", "Login");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Estudante já existente");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Escolha um curso correcto");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

    }
}
