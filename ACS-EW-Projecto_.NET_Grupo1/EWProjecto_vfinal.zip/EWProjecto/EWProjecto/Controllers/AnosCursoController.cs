﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class AnosCursoController : Controller
    {
        //
        // GET: /AnosCurso/

        [Authorize(Roles = "Administrador")]
        public ActionResult Add(string sigla)
        {
            AnosCursoModel model = new AnosCursoModel(sigla);
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(AnosCursoModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = CursosAnos.insere(model.anoCurso, model.sigla);
                if (inserted)
                {
                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Editar", "Cursos", new { sigla = model.sigla });
                }
                else
                {
                    ModelState.AddModelError("", "Ano do curso já existente");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(int oid)
        {
            CursoAno c = CursosAnos.getCursoAno(oid);
            string sigla = c.oidSigla;
            CursosAnos.remove(oid);
            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Editar", "Cursos", new { sigla = sigla });
        }

    }
}
