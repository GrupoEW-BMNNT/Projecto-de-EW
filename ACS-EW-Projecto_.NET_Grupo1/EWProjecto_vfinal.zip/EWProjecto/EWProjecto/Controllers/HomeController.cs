﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models.ModelViews;
using EWProjecto.Models;

namespace EWProjecto.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index(int? page)
        {
            List<ListaMaterialDidactico> listas = ListasMaterialDidactico.getAllListasMaterialDidactico();
            listas = listas.OrderByDescending(lm => lm.dataActualizacao).ThenBy(lm => lm.oidAnoLectivo).ToList();
            HomeModel model = new HomeModel(listas, page ?? 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Estudante")]
        public ActionResult Estudante(int? page)
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            List<ListaMaterialDidactico> listas = ListasMaterialDidactico.getListaMaterialDidacticoCursoAno(estudante.oidCursoAno);
            listas = listas.OrderByDescending(lm => lm.oidAnoLectivo).ThenBy(lm => lm.CursoAno.ano).ToList();
            HomeModel model = new HomeModel(listas, page ?? 0);
            ViewBag.username = User.Identity.Name;
            ViewBag.estudante = estudante;

            return View(model);
        }
    }
}
