﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class PedidosController : Controller
    {
        //
        // GET: /Pedidos/

        [Authorize(Roles = "Estudante")]
        public ActionResult Index(int? page, int? tipo)
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);
            List<PedidoImpressao> listaPedidosImpressao;

            if (tipo.HasValue == true)
            {
                listaPedidosImpressao = PedidosImpressao.getPedidoImpressaoEstudante(estudante.oidUtilizador, tipo.Value);
            }
            else
            {
                listaPedidosImpressao = PedidosImpressao.getPedidoImpressaoEstudante(estudante.oidUtilizador);
            }
            PedidosModel model = new PedidosModel(listaPedidosImpressao, page ?? 0);

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Estudante")]
        public ActionResult Index(PedidosModel model)
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);

            List<PedidoImpressao> listaPedidosImpressao = PedidosImpressao.getPedidoImpressaoEstudante(estudante.oidUtilizador, model.pedidoTipo);
            model.setMateriaisAndPage(listaPedidosImpressao, 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Estudante, Administrador")]
        public ActionResult Detalhes(int oid)
        {
            string username = User.Identity.Name;
            Estudante estudante = Estudantes.getEstudante(username);

            ViewBag.pedidoImpressao = PedidosImpressao.getPedidoImpressao(oid);

            ViewBag.username = User.Identity.Name;

            return View();
        }

        [Authorize(Roles = "Estudante")]
        public ActionResult Delete(int oid)
        {
            PedidosImpressao.remove(oid);

            ViewBag.username = User.Identity.Name;

            return RedirectToAction("Index", "Pedidos");
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Administrar(int? page)
        {
            List<PedidoImpressao> listaPedidosImpressao = PedidosImpressao.getAllPedidosImpressaoPendentes();
            PedidosModel model = new PedidosModel(listaPedidosImpressao, page ?? 0);

            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Administrar(PedidosModel model)
        {
            List<PedidoImpressao> listaPedidosImpressao = PedidosImpressao.getAllPedidosImpressaoPendentes();
            model.setMateriaisAndPage(listaPedidosImpressao, 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Aceitar(int oid)
        {
            PedidosImpressao.actualizaEstado(oid, true);

            ViewBag.username = User.Identity.Name;

            return RedirectToAction("Administrar", "Pedidos");
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Rejeitar(int oid)
        {
            PedidosImpressao.actualizaEstado(oid, false);

            ViewBag.username = User.Identity.Name;

            return RedirectToAction("Administrar", "Pedidos");
        }
    }
}
