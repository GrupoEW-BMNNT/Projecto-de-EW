﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EWProjecto.Models;
using EWProjecto.Models.ModelViews;

namespace EWProjecto.Controllers
{
    public class DisciplinasController : Controller
    {
        //
        // GET: /Disciplinas/

        [Authorize(Roles = "Administrador")]
        public ActionResult Index(int? page)
        {
            List<Disciplina> disciplinas = Disciplinas.getAllDisciplinas();
            disciplinas = disciplinas.OrderBy(d => d.nome).ToList();
            DisciplinaModel model = new DisciplinaModel(disciplinas, page ?? 0);
            ViewBag.username = User.Identity.Name;

            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Add()
        {
            DisciplinaModel model = new DisciplinaModel(new List<Disciplina>(), 0);
            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [HttpPost, Authorize(Roles = "Administrador")]
        public ActionResult Add(DisciplinaModel model)
        {
            if (ModelState.IsValid)
            {
                bool inserted = Disciplinas.insere(model.nome);
                if (inserted)
                {
                    ViewBag.username = User.Identity.Name;
                    return RedirectToAction("Index", "Disciplinas");
                }
                else
                {
                    ModelState.AddModelError("", "Disciplina já existente");
                }
            }

            ViewBag.username = User.Identity.Name;
            return View(model);
        }

        [Authorize(Roles = "Administrador")]
        public ActionResult Delete(int oid)
        {
            Disciplinas.remove(oid);
            ViewBag.username = User.Identity.Name;
            return RedirectToAction("Index", "Disciplinas");
        }

    }
}
